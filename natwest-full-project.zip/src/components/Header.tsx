import React from 'react';
import { useBanking } from '../context/BankingContext';
import { Bell, Sliders, LogOut } from 'lucide-react';

export const Header: React.FC = () => {
  const { account, setIsAdminOpen, setIsLoginModalOpen } = useBanking();

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const firstName = account.name.split(' ')[0] || 'there';

  return (
    <header className="bg-[#42145F] text-white px-5 pt-4 pb-5 select-none transition-all">
      <div className="flex items-center justify-between">
        {/* User Profile & Greeting */}
        <div className="flex items-center gap-3">
          <div
            onClick={() => setIsAdminOpen(true)}
            title="Click to customize account"
            className="w-10 h-10 rounded-full bg-[#5C237E] flex items-center justify-center font-bold text-sm tracking-wide border-2 border-white/20 shadow cursor-pointer active:scale-95 transition-transform"
          >
            {account.initials}
          </div>
          <div>
            <p className="text-xs text-purple-200 font-medium">{getGreeting()},</p>
            <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-1.5">
              <span>{firstName}</span>
            </h1>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Customization / Admin shortcut button */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 px-3 py-1.5 rounded-full text-xs font-semibold text-purple-100 transition-all shadow-sm"
            title="Customize your account, balances & transactions"
          >
            <Sliders size={13} className="text-purple-200" />
            <span>Customize</span>
          </button>

          {/* Notifications */}
          <button
            onClick={() => alert('No new notifications')}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/15 active:scale-95 flex items-center justify-center text-purple-100 transition-all relative"
            title="Notifications"
          >
            <Bell size={17} />
            <span className="w-2 h-2 rounded-full bg-red-400 absolute top-2 right-2 ring-2 ring-[#42145F]" />
          </button>

          {/* Lock / Log out */}
          <button
            onClick={() => setIsLoginModalOpen(true)}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/15 active:scale-95 flex items-center justify-center text-purple-100 transition-all"
            title="Lock app"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  );
};
