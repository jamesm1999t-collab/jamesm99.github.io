import React, { useState } from 'react';
import { useBanking } from '../context/BankingContext';
import { X, Plus, Sparkles, ArrowDownLeft, ArrowUpRight } from 'lucide-react';

export const PotsModal: React.FC = () => {
  const { pots, isPotsModalOpen, setIsPotsModalOpen, updatePot, updateBalance } = useBanking();
  const [selectedPotId, setSelectedPotId] = useState<string | null>(null);
  const [amount, setAmount] = useState('50');

  if (!isPotsModalOpen) return null;

  const handleDeposit = (potId: string) => {
    const num = parseFloat(amount);
    if (!num || num <= 0) return;
    updatePot(potId, num);
    updateBalance(-num);
  };

  const handleWithdraw = (potId: string) => {
    const num = parseFloat(amount);
    if (!num || num <= 0) return;
    updatePot(potId, -num);
    updateBalance(num);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Sparkles size={16} />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 text-sm">Savings Pots</h3>
              <p className="text-[10px] text-gray-400">Ringfence money towards your goals</p>
            </div>
          </div>
          <button
            onClick={() => setIsPotsModalOpen(false)}
            className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200"
          >
            <X size={14} />
          </button>
        </div>

        {/* Pots List */}
        <div className="space-y-3">
          {pots.map((pot) => {
            const pct = Math.min(100, Math.round((pot.current / pot.target) * 100));
            const isSelected = selectedPotId === pot.id;

            return (
              <div
                key={pot.id}
                className="bg-gray-50 rounded-2xl p-4 border border-gray-100 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-8 h-8 rounded-xl flex items-center justify-center text-white font-bold text-xs"
                      style={{ backgroundColor: pot.color }}
                    >
                      {pot.name[0]}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-gray-900">{pot.name}</h4>
                      <p className="text-[10px] text-gray-500">
                        Target: £{pot.target.toLocaleString('en-GB')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-gray-900">
                      £{pot.current.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                    </p>
                    <span className="text-[10px] font-semibold text-emerald-600">{pct}% reached</span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{ width: `${pct}%`, backgroundColor: pot.color }}
                  />
                </div>

                {/* Pot Action Controls */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleDeposit(pot.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white py-1.5 rounded-xl text-xs font-bold active:scale-95 transition-all"
                  >
                    <ArrowDownLeft size={13} />
                    <span>Add £{amount}</span>
                  </button>
                  <button
                    onClick={() => handleWithdraw(pot.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-gray-200 hover:bg-gray-300 text-gray-700 py-1.5 rounded-xl text-xs font-bold active:scale-95 transition-all"
                  >
                    <ArrowUpRight size={13} />
                    <span>Withdraw £{amount}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Amount Selector */}
        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
          <span className="text-[11px] font-semibold text-gray-500">Transfer step:</span>
          <div className="flex gap-1.5">
            {[10, 50, 100, 500].map((step) => (
              <button
                key={step}
                onClick={() => setAmount(step.toString())}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  amount === step.toString()
                    ? 'bg-[#42145F] text-white shadow-2xs'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                £{step}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
