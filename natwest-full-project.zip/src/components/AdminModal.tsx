import React, { useState } from 'react';
import { useBanking } from '../context/BankingContext';
import { PRESET_MERCHANTS } from '../data/initialData';
import { X, User, DollarSign, Plus, Trash2, RefreshCw, CheckCircle2, Shield, Sparkles } from 'lucide-react';

export const AdminModal: React.FC = () => {
  const {
    account,
    accounts,
    transactions,
    isAdminOpen,
    setIsAdminOpen,
    updateAccount,
    updateBalance,
    setExactBalance,
    addTransaction,
    deleteTransaction,
    resetToDefaults,
  } = useBanking();

  const [activeTab, setActiveTab] = useState<'details' | 'balance' | 'transactions' | 'merchants'>('details');

  // Custom transaction state
  const [customPayee, setCustomPayee] = useState('');
  const [customAmount, setCustomAmount] = useState('');
  const [customType, setCustomType] = useState<'out' | 'in'>('out');
  const [customCategory, setCustomCategory] = useState<'Shopping' | 'Groceries' | 'Bills' | 'Income' | 'Entertainment' | 'Eating Out' | 'Travel' | 'General'>('Shopping');
  const [customRef, setCustomRef] = useState('');

  // Balance direct edit
  const [tempBalance, setTempBalance] = useState(account.balance.toString());
  const [tempSavings, setTempSavings] = useState(account.savingsBalance.toString());
  const [tempLinked, setTempLinked] = useState(account.linkedBalance.toString());

  if (!isAdminOpen) return null;

  const handleSaveDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAdminOpen(false);
  };

  const handleAddCustomTx = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(customAmount);
    if (!amt || amt <= 0 || !customPayee.trim()) return;

    addTransaction({
      payeeName: customPayee.toUpperCase().trim(),
      payeeInitials: customPayee.slice(0, 2).toUpperCase(),
      amount: amt,
      type: customType,
      category: customCategory,
      reference: customRef || (customType === 'in' ? 'Bank Transfer' : 'Card Payment'),
      date: new Date().toISOString(),
    });

    setCustomPayee('');
    setCustomAmount('');
    setCustomRef('');
  };

  const handleAddPresetMerchant = (merchant: (typeof PRESET_MERCHANTS)[number]) => {
    const defaultAmts = [15.5, 29.99, 45.0, 78.2, 120.0];
    const randomAmt = defaultAmts[Math.floor(Math.random() * defaultAmts.length)];
    const isIncome = 'defaultType' in merchant && merchant.defaultType === 'in';

    addTransaction({
      payeeName: merchant.name,
      payeeInitials: merchant.name.slice(0, 2).toUpperCase(),
      amount: isIncome ? 3000.0 : randomAmt,
      type: isIncome ? 'in' : 'out',
      category: merchant.category as any,
      reference: isIncome ? 'Direct Credit' : 'Contactless Payment',
      date: new Date().toISOString(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-[#42145F] text-white px-5 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center font-bold">
              <Sparkles size={16} />
            </div>
            <div>
              <h2 className="text-base font-bold">Make This App Your Own</h2>
              <p className="text-[11px] text-purple-200">Customize accounts, balances, and transactions</p>
            </div>
          </div>
          <button
            onClick={() => setIsAdminOpen(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
          >
            <X size={16} />
          </button>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex border-b border-gray-100 bg-gray-50/80 px-4 pt-2 gap-2 text-xs font-semibold overflow-x-auto scrollbar-none flex-shrink-0">
          {[
            { id: 'details', label: 'Account Details' },
            { id: 'balance', label: 'Balances' },
            { id: 'transactions', label: `Transactions (${transactions.length})` },
            { id: 'merchants', label: 'Preset Merchants' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-2.5 px-3 border-b-2 transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-[#42145F] text-[#42145F] font-bold'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* TAB 1: ACCOUNT DETAILS */}
          {activeTab === 'details' && (
            <form onSubmit={handleSaveDetails} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Account Holder Name</label>
                  <input
                    type="text"
                    value={account.name}
                    onChange={(e) => updateAccount({ name: e.target.value.toUpperCase() })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F] font-semibold"
                  />
                </div>
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Account Nickname</label>
                  <input
                    type="text"
                    value={account.accountName}
                    onChange={(e) => updateAccount({ accountName: e.target.value })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Initials</label>
                  <input
                    type="text"
                    maxLength={3}
                    value={account.initials}
                    onChange={(e) => updateAccount({ initials: e.target.value.toUpperCase() })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F] font-bold text-center"
                  />
                </div>
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Sort Code</label>
                  <input
                    type="text"
                    value={account.sortCode}
                    onChange={(e) => updateAccount({ sortCode: e.target.value })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 font-mono text-center focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Account Number</label>
                  <input
                    type="text"
                    value={account.accountNumber}
                    onChange={(e) => updateAccount({ accountNumber: e.target.value })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 font-mono text-center focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Phone Number</label>
                  <input
                    type="text"
                    value={account.phone}
                    onChange={(e) => updateAccount({ phone: e.target.value })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
                <div>
                  <label className="text-gray-500 font-semibold text-[10px] uppercase">Email</label>
                  <input
                    type="email"
                    value={account.email}
                    onChange={(e) => updateAccount({ email: e.target.value })}
                    className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-500 font-semibold text-[10px] uppercase">Postal Address</label>
                <textarea
                  rows={2}
                  value={account.address}
                  onChange={(e) => updateAccount({ address: e.target.value })}
                  className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                />
              </div>

              <div>
                <label className="text-gray-500 font-semibold text-[10px] uppercase">App Security PIN</label>
                <input
                  type="text"
                  maxLength={6}
                  value={account.pin}
                  onChange={(e) => updateAccount({ pin: e.target.value })}
                  className="w-full mt-1 p-2 bg-gray-50 rounded-xl border border-gray-200 font-mono font-bold text-center tracking-widest focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 bg-[#42145F] text-white py-2.5 rounded-xl font-bold shadow-xs active:scale-95 transition-all"
              >
                Save Changes
              </button>
            </form>
          )}

          {/* TAB 2: BALANCES */}
          {activeTab === 'balance' && (
            <div className="space-y-4">
              {/* Current Account Balance */}
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-gray-800 text-xs uppercase">Current Account Balance</span>
                  <span className="font-black text-sm text-[#42145F]">
                    £{account.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="flex gap-2 mb-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-2 font-bold text-gray-400">£</span>
                    <input
                      type="number"
                      step="0.01"
                      value={tempBalance}
                      onChange={(e) => setTempBalance(e.target.value)}
                      className="w-full pl-7 pr-3 py-1.5 bg-white rounded-lg border border-gray-200 font-bold focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                    />
                  </div>
                  <button
                    onClick={() => {
                      const val = parseFloat(tempBalance);
                      if (!isNaN(val)) setExactBalance(val);
                    }}
                    className="bg-[#42145F] text-white px-3 py-1.5 rounded-lg font-bold"
                  >
                    Set
                  </button>
                </div>

                {/* Quick Increment Buttons */}
                <div className="grid grid-cols-4 gap-1.5 mt-2">
                  {[100, 500, 1000, 5000].map((amt) => (
                    <button
                      key={amt}
                      onClick={() => updateBalance(amt)}
                      className="py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-md"
                    >
                      +£{amt}
                    </button>
                  ))}
                  {[100, 500, 1000, 5000].map((amt) => (
                    <button
                      key={`min-${amt}`}
                      onClick={() => updateBalance(-amt)}
                      className="py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-md"
                    >
                      -£{amt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Savings Account Balance */}
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-gray-800 text-xs uppercase">Digital Regular Saver</span>
                  <span className="font-black text-sm text-emerald-700">
                    £{account.savingsBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-2 font-bold text-gray-400">£</span>
                    <input
                      type="number"
                      step="0.01"
                      value={tempSavings}
                      onChange={(e) => setTempSavings(e.target.value)}
                      className="w-full pl-7 pr-3 py-1.5 bg-white rounded-lg border border-gray-200 font-bold"
                    />
                  </div>
                  <button
                    onClick={() => {
                      const val = parseFloat(tempSavings);
                      if (!isNaN(val)) updateAccount({ savingsBalance: val });
                    }}
                    className="bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-bold"
                  >
                    Set
                  </button>
                </div>
              </div>

              {/* Linked Account Balance */}
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-gray-800 text-xs uppercase">Linked Monzo Account</span>
                  <span className="font-black text-sm text-orange-600">
                    £{account.linkedBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-2 font-bold text-gray-400">£</span>
                    <input
                      type="number"
                      step="0.01"
                      value={tempLinked}
                      onChange={(e) => setTempLinked(e.target.value)}
                      className="w-full pl-7 pr-3 py-1.5 bg-white rounded-lg border border-gray-200 font-bold"
                    />
                  </div>
                  <button
                    onClick={() => {
                      const val = parseFloat(tempLinked);
                      if (!isNaN(val)) updateAccount({ linkedBalance: val });
                    }}
                    className="bg-orange-600 text-white px-3 py-1.5 rounded-lg font-bold"
                  >
                    Set
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TRANSACTIONS */}
          {activeTab === 'transactions' && (
            <div className="space-y-4">
              {/* Add Custom Transaction Form */}
              <form onSubmit={handleAddCustomTx} className="bg-gray-50 p-3.5 rounded-2xl border border-gray-100 space-y-2.5">
                <h4 className="font-bold text-gray-800 text-xs">Add Custom Transaction</h4>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Payee Name (e.g. Apple, Tesco)"
                    value={customPayee}
                    onChange={(e) => setCustomPayee(e.target.value)}
                    className="p-2 bg-white rounded-xl border border-gray-200 text-xs"
                  />
                  <div className="relative">
                    <span className="absolute left-2.5 top-2 text-gray-400 font-bold">£</span>
                    <input
                      type="number"
                      step="0.01"
                      required
                      placeholder="Amount"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(e.target.value)}
                      className="w-full pl-6 p-2 bg-white rounded-xl border border-gray-200 text-xs font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <select
                    value={customType}
                    onChange={(e) => setCustomType(e.target.value as any)}
                    className="p-2 bg-white rounded-xl border border-gray-200 text-xs font-semibold"
                  >
                    <option value="out">Expense (Out -)</option>
                    <option value="in">Income (In +)</option>
                  </select>

                  <select
                    value={customCategory}
                    onChange={(e) => setCustomCategory(e.target.value as any)}
                    className="p-2 bg-white rounded-xl border border-gray-200 text-xs"
                  >
                    <option value="Shopping">Shopping</option>
                    <option value="Groceries">Groceries</option>
                    <option value="Eating Out">Eating Out</option>
                    <option value="Bills">Bills</option>
                    <option value="Entertainment">Entertainment</option>
                    <option value="Income">Income</option>
                    <option value="Travel">Travel</option>
                  </select>

                  <input
                    type="text"
                    placeholder="Reference"
                    value={customRef}
                    onChange={(e) => setCustomRef(e.target.value)}
                    className="p-2 bg-white rounded-xl border border-gray-200 text-xs"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#42145F] text-white py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                >
                  <Plus size={14} /> Add Transaction
                </button>
              </form>

              {/* Current Transactions List */}
              <div className="space-y-1.5 max-h-60 overflow-y-auto">
                {transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-2.5 bg-gray-50 rounded-xl border border-gray-100"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="font-bold text-gray-800 truncate">{tx.payeeName}</p>
                      <p className="text-[10px] text-gray-400">
                        {tx.type === 'in' ? '+' : '-'}£{tx.amount.toFixed(2)} · {tx.category}
                      </p>
                    </div>
                    <button
                      onClick={() => deleteTransaction(tx.id)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg flex-shrink-0"
                      title="Delete transaction"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PRESET MERCHANTS */}
          {activeTab === 'merchants' && (
            <div>
              <p className="text-gray-500 mb-3 text-[11px]">
                Click any merchant to instantly add a realistic UK transaction:
              </p>
              <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
                {PRESET_MERCHANTS.map((m, i) => (
                  <button
                    key={i}
                    onClick={() => handleAddPresetMerchant(m)}
                    className="p-2.5 bg-gray-50 hover:bg-purple-50 active:scale-95 border border-gray-200 rounded-xl text-left flex items-center justify-between transition-all"
                  >
                    <div className="min-w-0">
                      <p className="font-bold text-gray-800 truncate text-[11px]">{m.name}</p>
                      <p className="text-[9px] text-gray-400 capitalize">{m.category}</p>
                    </div>
                    <Plus size={13} className="text-[#42145F] flex-shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between flex-shrink-0">
          <button
            onClick={() => {
              if (confirm('Reset all balances, payees, and transactions to default settings?')) {
                resetToDefaults();
                setIsAdminOpen(false);
              }
            }}
            className="flex items-center gap-1.5 text-gray-500 hover:text-rose-600 font-semibold text-xs"
          >
            <RefreshCw size={13} />
            <span>Reset Defaults</span>
          </button>

          <button
            onClick={() => setIsAdminOpen(false)}
            className="bg-[#42145F] text-white px-5 py-2 rounded-xl font-bold text-xs shadow-sm active:scale-95 transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
