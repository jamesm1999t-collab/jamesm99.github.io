import React, { useState } from 'react';
import { useBanking } from '../context/BankingContext';
import { X, Lock, Unlock, Eye, EyeOff, ShieldCheck, Wifi } from 'lucide-react';

export const CardsModal: React.FC = () => {
  const { account, isCardsModalOpen, setIsCardsModalOpen } = useBanking();
  const [isFrozen, setIsFrozen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [showPin, setShowPin] = useState(false);

  if (!isCardsModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-gray-900 text-sm">Manage Debit Card</h3>
          <button
            onClick={() => setIsCardsModalOpen(false)}
            className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200"
          >
            <X size={14} />
          </button>
        </div>

        {/* Realistic Virtual NatWest Debit Card */}
        <div
          className={`w-full h-48 rounded-2xl p-5 text-white shadow-xl relative overflow-hidden transition-all duration-300 ${
            isFrozen
              ? 'bg-gradient-to-tr from-gray-700 to-gray-900 opacity-90 grayscale'
              : 'bg-gradient-to-tr from-[#42145F] via-[#5C237E] to-[#250738]'
          }`}
        >
          {isFrozen && (
            <div className="absolute inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-20">
              <span className="bg-white/20 border border-white/30 px-3 py-1 rounded-full text-xs font-bold tracking-wide flex items-center gap-1.5">
                <Lock size={12} /> CARD FROZEN
              </span>
            </div>
          )}

          {/* Top row */}
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[11px] font-bold tracking-widest uppercase text-purple-200">NatWest</p>
              <p className="text-[9px] text-purple-300">Debit</p>
            </div>
            <Wifi size={18} className="text-purple-200 rotate-90" />
          </div>

          {/* Chip */}
          <div className="w-9 h-7 rounded-md bg-amber-300/80 border border-amber-400 mt-3 shadow-inner" />

          {/* Card Number */}
          <div className="mt-3 font-mono text-sm tracking-widest font-semibold">
            {showDetails ? '5412 7500 8912 3042' : '•••• •••• •••• 3042'}
          </div>

          {/* Footer info */}
          <div className="flex justify-between items-end mt-2">
            <div>
              <p className="text-[8px] text-purple-300 uppercase">Card Holder</p>
              <p className="text-[11px] font-bold tracking-wide">{account.name}</p>
            </div>
            <div className="text-right">
              <p className="text-[8px] text-purple-300 uppercase">Expires / CVV</p>
              <p className="text-[11px] font-mono font-bold">
                {showDetails ? '08/29 · 419' : '••/•• · •••'}
              </p>
            </div>
          </div>
        </div>

        {/* Card Controls */}
        <div className="mt-5 space-y-3">
          {/* Freeze Toggle */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl border border-gray-100">
            <div className="flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  isFrozen ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'
                }`}
              >
                {isFrozen ? <Lock size={18} /> : <Unlock size={18} />}
              </div>
              <div>
                <p className="text-xs font-bold text-gray-900">{isFrozen ? 'Card is Frozen' : 'Card is Active'}</p>
                <p className="text-[10px] text-gray-400">
                  {isFrozen ? 'No new payments allowed' : 'Ready for contactless & online'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsFrozen(!isFrozen)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                isFrozen ? 'bg-rose-600 text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              {isFrozen ? 'Unfreeze' : 'Freeze'}
            </button>
          </div>

          {/* Show Card Details */}
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 rounded-2xl border border-gray-100 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-50 text-[#42145F] flex items-center justify-center">
                {showDetails ? <EyeOff size={18} /> : <Eye size={18} />}
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-gray-900">
                  {showDetails ? 'Hide Card Details' : 'View Card Number & CVV'}
                </p>
                <p className="text-[10px] text-gray-400">Security protected</p>
              </div>
            </div>
          </button>

          {/* View PIN */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl border border-gray-100">
            <div className="text-left">
              <p className="text-xs font-bold text-gray-900">Card PIN</p>
              <p className="text-[10px] text-gray-400">Used for ATM and chip & pin</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm font-bold text-gray-800">
                {showPin ? account.pin : '••••'}
              </span>
              <button
                onClick={() => setShowPin(!showPin)}
                className="text-xs font-semibold text-[#42145F] hover:underline"
              >
                {showPin ? 'Hide' : 'Reveal'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
