import React, { useState } from 'react';
import { useBanking } from '../context/BankingContext';
import { Transaction } from '../types';
import { Search, ShoppingBag, Utensils, Zap, DollarSign, Film, Compass, ChevronRight } from 'lucide-react';

export const TransactionList: React.FC = () => {
  const { transactions, setSelectedTransaction } = useBanking();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Groceries', 'Shopping', 'Bills', 'Income', 'Eating Out', 'Entertainment'];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Groceries':
      case 'Shopping':
        return <ShoppingBag size={15} />;
      case 'Eating Out':
        return <Utensils size={15} />;
      case 'Bills':
        return <Zap size={15} />;
      case 'Income':
        return <DollarSign size={15} />;
      case 'Entertainment':
        return <Film size={15} />;
      default:
        return <Compass size={15} />;
    }
  };

  const filtered = transactions.filter((t) => {
    const matchesSearch =
      t.payeeName.toLowerCase().includes(search.toLowerCase()) ||
      (t.reference && t.reference.toLowerCase().includes(search.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || t.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    const today = new Date();
    if (d.toDateString() === today.toDateString()) {
      return 'Today';
    }
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    if (d.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  };

  return (
    <div className="px-4 py-3 pb-24">
      <div className="flex items-center justify-between mb-2.5">
        <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
          Recent Activity ({filtered.length})
        </h2>
      </div>

      {/* Search Input */}
      <div className="relative mb-3">
        <Search className="absolute left-3 top-2.5 text-gray-400" size={15} />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search transactions or references..."
          className="w-full bg-white rounded-xl pl-9 pr-4 py-2 text-xs border border-gray-100 shadow-2xs focus:outline-none focus:ring-1 focus:ring-[#42145F] text-gray-800 placeholder:text-gray-400"
        />
      </div>

      {/* Category Filter Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-2 mb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-[#42145F] text-white shadow-xs'
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-100'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Transactions List */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-xs divide-y divide-gray-50 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-gray-400 text-xs">No transactions found</div>
        ) : (
          filtered.map((tx: Transaction) => {
            const isIncome = tx.type === 'in';
            return (
              <div
                key={tx.id}
                onClick={() => setSelectedTransaction(tx)}
                className="px-4 py-3 flex items-center justify-between hover:bg-purple-50/40 active:bg-purple-100/30 transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                      isIncome
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-gray-100 text-gray-700 group-hover:bg-[#42145F] group-hover:text-white transition-colors'
                    }`}
                  >
                    {tx.payeeInitials}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-gray-900 truncate">{tx.payeeName}</p>
                    <p className="text-[10px] text-gray-400 truncate flex items-center gap-1">
                      <span>{formatDate(tx.date)}</span>
                      <span>·</span>
                      <span>{tx.reference || tx.category}</span>
                    </p>
                  </div>
                </div>

                <div className="text-right flex items-center gap-2 flex-shrink-0">
                  <div>
                    <p
                      className={`text-xs font-bold ${
                        isIncome ? 'text-emerald-600 font-extrabold' : 'text-gray-900'
                      }`}
                    >
                      {isIncome ? '+' : '-'}£
                      {tx.amount.toLocaleString('en-GB', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </p>
                    <span className="text-[9px] text-gray-400 capitalize">{tx.category}</span>
                  </div>
                  <ChevronRight size={14} className="text-gray-300 group-hover:text-gray-600" />
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
