import React, { useState } from 'react';
import { useBanking } from '../context/BankingContext';
import { Payee } from '../types';
import { UserPlus, ArrowRight, ShieldCheck, CheckCircle2, X } from 'lucide-react';

export const PaymentsScreen: React.FC = () => {
  const { payees, addPayee, transferMoney, account } = useBanking();

  const [selectedPayee, setSelectedPayee] = useState<Payee | null>(null);
  const [isNewPayeeModal, setIsNewPayeeModal] = useState(false);
  const [newPayeeName, setNewPayeeName] = useState('');
  const [newPayeeAcc, setNewPayeeAcc] = useState('');
  const [newPayeeSort, setNewPayeeSort] = useState('');

  // Payment form state
  const [amount, setAmount] = useState('');
  const [reference, setReference] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const quickAmounts = [10, 25, 50, 100, 250];

  const handleSelectPayee = (p: Payee) => {
    setSelectedPayee(p);
    setPaymentSuccess(false);
  };

  const handleCreatePayee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPayeeName || !newPayeeAcc || !newPayeeSort) return;
    const initials = newPayeeName
      .split(' ')
      .map((w) => w[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();

    addPayee({
      name: newPayeeName,
      initials,
      accountNumber: newPayeeAcc,
      sortCode: newPayeeSort,
      isFavourite: true,
    });

    setIsNewPayeeModal(false);
    setNewPayeeName('');
    setNewPayeeAcc('');
    setNewPayeeSort('');
  };

  const handleSendPayment = async () => {
    if (!selectedPayee) return;
    const num = parseFloat(amount);
    if (!num || num <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    setIsAuthenticating(true);

    // Simulate NatWest Biometric / Passcode security check
    setTimeout(async () => {
      const ok = await transferMoney(
        selectedPayee.accountNumber,
        selectedPayee.sortCode,
        num,
        reference || 'PAYMENT',
        selectedPayee.name
      );

      setIsAuthenticating(false);
      if (ok) {
        setPaymentSuccess(true);
      } else {
        alert('Payment failed: insufficient funds');
      }
    }, 1200);
  };

  return (
    <div className="px-4 py-4 pb-28 max-w-md mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-xl font-bold text-gray-900 tracking-tight">Payments & Transfers</h1>
          <p className="text-xs text-gray-500">Fast, free transfers to any UK account</p>
        </div>
        <button
          onClick={() => setIsNewPayeeModal(true)}
          className="flex items-center gap-1.5 bg-[#42145F] text-white px-3 py-1.5 rounded-full text-xs font-semibold hover:bg-purple-900 active:scale-95 transition-all shadow-sm"
        >
          <UserPlus size={14} />
          <span>Pay New</span>
        </button>
      </div>

      {/* Favourite Payees List */}
      <div className="mb-6">
        <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Saved Payees</h2>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
          {payees.map((p) => {
            const isSelected = selectedPayee?.id === p.id;
            return (
              <button
                key={p.id}
                onClick={() => handleSelectPayee(p)}
                className={`flex flex-col items-center min-w-[70px] p-2 rounded-2xl transition-all ${
                  isSelected ? 'bg-purple-100 ring-2 ring-[#42145F]' : 'hover:bg-gray-100'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-sm shadow-xs ${
                    isSelected ? 'bg-[#42145F] text-white' : 'bg-purple-50 text-[#42145F]'
                  }`}
                >
                  {p.initials}
                </div>
                <span className="text-[11px] font-semibold text-gray-800 mt-1.5 truncate w-16 text-center">
                  {p.name.split(' ')[0]}
                </span>
                <span className="text-[9px] text-gray-400 font-mono">{p.sortCode}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Payment Form */}
      {selectedPayee && (
        <div className="bg-white rounded-3xl p-5 border border-gray-100 shadow-md animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-gray-100">
            <div>
              <p className="text-[10px] text-gray-400 uppercase font-semibold">Paying</p>
              <h3 className="font-bold text-gray-900 text-sm">{selectedPayee.name}</h3>
              <p className="text-[10px] text-gray-400 font-mono">
                {selectedPayee.sortCode} · {selectedPayee.accountNumber}
              </p>
            </div>
            <button
              onClick={() => setSelectedPayee(null)}
              className="text-gray-400 hover:text-gray-600 p-1"
            >
              <X size={16} />
            </button>
          </div>

          {paymentSuccess ? (
            <div className="text-center py-6">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center mb-3 animate-bounce">
                <CheckCircle2 size={36} />
              </div>
              <h3 className="text-lg font-bold text-gray-900">Payment Sent!</h3>
              <p className="text-xs text-gray-500 mt-1">
                £{parseFloat(amount).toFixed(2)} sent to {selectedPayee.name}
              </p>
              <button
                onClick={() => {
                  setSelectedPayee(null);
                  setAmount('');
                  setReference('');
                  setPaymentSuccess(false);
                }}
                className="mt-5 w-full bg-[#42145F] text-white py-3 rounded-xl text-xs font-bold active:scale-95 transition-all"
              >
                Done
              </button>
            </div>
          ) : (
            <div className="pt-4 space-y-4">
              <div>
                <label className="text-[11px] font-semibold text-gray-500">Amount (£)</label>
                <div className="relative mt-1">
                  <span className="absolute left-3 top-3 text-lg font-bold text-gray-400">£</span>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full pl-8 pr-4 py-2.5 text-xl font-bold bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#42145F]"
                  />
                </div>

                {/* Quick Chips */}
                <div className="flex gap-1.5 mt-2">
                  {quickAmounts.map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setAmount(q.toString())}
                      className="flex-1 py-1 bg-gray-100 hover:bg-gray-200 rounded-lg text-[11px] font-semibold text-gray-700 transition-colors"
                    >
                      +£{q}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-gray-500">Payment Reference</label>
                <input
                  type="text"
                  maxLength={18}
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  placeholder="e.g. Dinner, Rent, Gift"
                  className="w-full mt-1 px-3 py-2 text-xs bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  disabled={isAuthenticating}
                  onClick={handleSendPayment}
                  className="w-full flex items-center justify-center gap-2 bg-[#42145F] hover:bg-purple-900 active:scale-98 text-white py-3.5 rounded-2xl font-bold text-sm shadow-md transition-all disabled:opacity-50"
                >
                  {isAuthenticating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                      <span>Verifying Biometrics...</span>
                    </>
                  ) : (
                    <>
                      <span>Send Payment</span>
                      <ArrowRight size={16} />
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[10px] text-gray-400">
                <ShieldCheck size={12} className="text-emerald-600" />
                <span>Protected by NatWest Confirmation of Payee</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* New Payee Modal */}
      {isNewPayeeModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900 text-sm">Add New Payee</h3>
              <button
                onClick={() => setIsNewPayeeModal(false)}
                className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-gray-500"
              >
                <X size={14} />
              </button>
            </div>

            <form onSubmit={handleCreatePayee} className="space-y-3">
              <div>
                <label className="text-[10px] font-semibold text-gray-500 uppercase">Payee Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Morgan"
                  value={newPayeeName}
                  onChange={(e) => setNewPayeeName(e.target.value)}
                  className="w-full mt-1 px-3 py-2 text-xs bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-gray-500 uppercase">Sort Code</label>
                  <input
                    type="text"
                    required
                    maxLength={8}
                    placeholder="60-12-34"
                    value={newPayeeSort}
                    onChange={(e) => setNewPayeeSort(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs font-mono bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-gray-500 uppercase">Account Number</label>
                  <input
                    type="text"
                    required
                    maxLength={8}
                    placeholder="12345678"
                    value={newPayeeAcc}
                    onChange={(e) => setNewPayeeAcc(e.target.value)}
                    className="w-full mt-1 px-3 py-2 text-xs font-mono bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-1 focus:ring-[#42145F]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-3 bg-[#42145F] text-white py-2.5 rounded-xl font-bold text-xs shadow-sm hover:bg-purple-900 active:scale-95 transition-all"
              >
                Save Payee
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
