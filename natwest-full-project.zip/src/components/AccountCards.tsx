import React, { useRef } from 'react';
import { useBanking } from '../context/BankingContext';
import { ChevronRight, Copy, Check, TrendingUp, PiggyBank, CreditCard, Sparkles } from 'lucide-react';

export const AccountCards: React.FC = () => {
  const { account, pots, setIsAdminOpen, setIsPotsModalOpen, setIsCardsModalOpen } = useBanking();
  const [copied, setCopied] = React.useState(false);
  const clickCountRef = useRef(0);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Triple tap on logo triggers admin/edit mode
  const handleLogoTap = (e: React.MouseEvent) => {
    e.stopPropagation();
    clickCountRef.current += 1;
    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);

    if (clickCountRef.current >= 3) {
      clickCountRef.current = 0;
      setIsAdminOpen(true);
    } else {
      clickTimerRef.current = setTimeout(() => {
        clickCountRef.current = 0;
      }, 600);
    }
  };

  const copyDetails = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(`Sort Code: ${account.sortCode}\nAccount: ${account.accountNumber}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const totalPotsBalance = pots.reduce((acc, p) => acc + p.current, 0);

  return (
    <div className="px-4 -mt-2 space-y-3">
      {/* 1. Main Current Account Card */}
      <div
        data-testid="account-card"
        onClick={() => setIsAdminOpen(true)}
        className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer relative group"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5" onClick={handleLogoTap}>
            <div className="w-8 h-8 rounded-lg bg-[#42145F] flex items-center justify-center text-white shadow-sm flex-shrink-0 group-hover:scale-105 transition-transform">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-gray-900 text-sm">{account.accountName || 'Current account'}</h3>
                <span className="text-[10px] font-semibold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">
                  Primary
                </span>
              </div>
              <p className="text-xs text-gray-400 font-mono flex items-center gap-1.5 mt-0.5">
                <span>{account.sortCode}</span>
                <span>·</span>
                <span>{account.accountNumber}</span>
                <button
                  onClick={copyDetails}
                  className="hover:text-gray-700 p-0.5"
                  title="Copy account details"
                >
                  {copied ? <Check size={11} className="text-emerald-600" /> : <Copy size={11} />}
                </button>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-[#42145F]">
            <span className="text-[11px] font-medium text-gray-400 group-hover:text-purple-700">Edit</span>
            <ChevronRight size={18} className="text-gray-400 group-hover:text-[#42145F] group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Balance Display */}
        <div className="flex items-baseline justify-between mt-4 pt-3 border-t border-gray-50">
          <div>
            <p className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">Available Balance</p>
            <p className="text-2xl font-black text-gray-900 tracking-tight mt-0.5">
              £{account.balance.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
          <div className="text-right">
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
              <TrendingUp size={11} /> Overdraft £{account.overdraftLimit.toLocaleString('en-GB')}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Secondary Accounts Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* Digital Regular Saver */}
        <div
          onClick={() => setIsAdminOpen(true)}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-start justify-between">
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <PiggyBank size={16} />
            </div>
            <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/70 px-1.5 py-0.5 rounded">
              6.17% AER
            </span>
          </div>
          <div className="mt-3">
            <p className="text-xs font-semibold text-gray-700 truncate">Digital Saver</p>
            <p className="text-base font-bold text-gray-900 mt-0.5">
              £{account.savingsBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-[10px] text-gray-400 font-mono mt-0.5">
              {account.savingsSortCode} · {account.savingsAccountNumber}
            </p>
          </div>
        </div>

        {/* Savings Pots */}
        <div
          onClick={() => setIsPotsModalOpen(true)}
          className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-start justify-between">
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Sparkles size={16} />
            </div>
            <span className="text-[10px] font-bold text-blue-800 bg-blue-100/70 px-1.5 py-0.5 rounded">
              {pots.length} Pots
            </span>
          </div>
          <div className="mt-3">
            <p className="text-xs font-semibold text-gray-700 truncate">Goals & Pots</p>
            <p className="text-base font-bold text-gray-900 mt-0.5">
              £{totalPotsBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
            </p>
            <div className="w-full bg-gray-100 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-blue-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, (totalPotsBalance / 30000) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 3. Linked Monzo Account Banner */}
      <div
        onClick={() => setIsAdminOpen(true)}
        className="bg-gradient-to-r from-orange-50/70 to-pink-50/70 rounded-xl px-4 py-2.5 border border-orange-100/80 flex items-center justify-between cursor-pointer hover:shadow-sm transition-all"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-md bg-[#FF5C5C] text-white flex items-center justify-center text-[10px] font-bold shadow-xs">
            M
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-800">Monzo Current Account</p>
            <p className="text-[10px] text-gray-500 font-mono">
              {account.linkedSortCode} · {account.linkedAccountNumber}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs font-bold text-gray-900">
            £{account.linkedBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
          </p>
          <span className="text-[9px] text-orange-600 font-medium">Open Banking</span>
        </div>
      </div>
    </div>
  );
};
