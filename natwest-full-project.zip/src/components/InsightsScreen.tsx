import React from 'react';
import { useBanking } from '../context/BankingContext';
import { TrendingDown, PieChart, ShoppingBag, Utensils, Zap, Compass, Film, AlertCircle } from 'lucide-react';

export const InsightsScreen: React.FC = () => {
  const { transactions } = useBanking();

  // Aggregate spending by category
  const outTxs = transactions.filter((t) => t.type === 'out');
  const totalOut = outTxs.reduce((acc, t) => acc + t.amount, 0);

  const categoryTotals: Record<string, number> = {};
  outTxs.forEach((t) => {
    categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
  });

  const categoriesSorted = Object.entries(categoryTotals).sort((a, b) => b[1] - a[1]);

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Groceries':
        return 'bg-emerald-500';
      case 'Shopping':
        return 'bg-purple-500';
      case 'Eating Out':
        return 'bg-orange-500';
      case 'Bills':
        return 'bg-blue-500';
      case 'Entertainment':
        return 'bg-pink-500';
      default:
        return 'bg-gray-400';
    }
  };

  return (
    <div className="px-4 py-4 pb-28 max-w-md mx-auto">
      <div className="mb-4">
        <h1 className="text-xl font-bold text-gray-900 tracking-tight">Spending Insights</h1>
        <p className="text-xs text-gray-500">Track and manage your monthly money habits</p>
      </div>

      {/* Hero Overview */}
      <div className="bg-gradient-to-br from-[#42145F] to-[#250738] rounded-3xl p-5 text-white shadow-md mb-4">
        <div className="flex items-center justify-between text-xs text-purple-200">
          <span>Total Spent This Month</span>
          <span className="flex items-center gap-1 text-emerald-300 font-semibold bg-white/10 px-2 py-0.5 rounded-full">
            <TrendingDown size={12} /> -8.4% vs last month
          </span>
        </div>
        <p className="text-3xl font-black mt-2 tracking-tight">
          £{totalOut.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
        </p>
        <p className="text-[11px] text-purple-200/80 mt-1">Across {outTxs.length} outgoings</p>

        {/* Progress Bar of Top Categories */}
        <div className="w-full h-2.5 rounded-full bg-white/15 overflow-hidden flex gap-0.5 mt-4">
          {categoriesSorted.map(([cat, amt]) => {
            const pct = (amt / (totalOut || 1)) * 100;
            return (
              <div
                key={cat}
                title={`${cat}: £${amt.toFixed(2)} (${pct.toFixed(0)}%)`}
                className={`${getCategoryColor(cat)} h-full transition-all`}
                style={{ width: `${pct}%` }}
              />
            );
          })}
        </div>
      </div>

      {/* Category Breakdown */}
      <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2.5">
        Breakdown by Category
      </h2>
      <div className="bg-white rounded-2xl border border-gray-100 shadow-2xs divide-y divide-gray-50 overflow-hidden mb-4">
        {categoriesSorted.map(([cat, amt]) => {
          const pct = Math.round((amt / (totalOut || 1)) * 100);
          return (
            <div key={cat} className="p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-3.5 h-3.5 rounded-full ${getCategoryColor(cat)} flex-shrink-0`} />
                <div>
                  <p className="text-xs font-bold text-gray-800">{cat}</p>
                  <p className="text-[10px] text-gray-400">{pct}% of total spending</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs font-bold text-gray-900">
                  £{amt.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Budget Tip */}
      <div className="bg-purple-50 rounded-2xl p-4 border border-purple-100 flex items-start gap-3">
        <AlertCircle size={18} className="text-[#42145F] flex-shrink-0 mt-0.5" />
        <div>
          <h4 className="text-xs font-bold text-[#42145F]">Great pacing!</h4>
          <p className="text-[11px] text-purple-900/80 leading-relaxed mt-0.5">
            You're currently on track to save approximately £340 more this month compared to your typical baseline. Keep it up!
          </p>
        </div>
      </div>
    </div>
  );
};
