import React, { useState } from 'react';
import { useBanking } from '../context/BankingContext';
import { Fingerprint, Delete, Shield, Check } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { account, isLoginModalOpen, setIsLoginModalOpen } = useBanking();
  const [pinInput, setPinInput] = useState('');
  const [error, setError] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isLoginModalOpen) return null;

  const handleDigit = (digit: string) => {
    if (pinInput.length >= 4) return;
    const next = pinInput + digit;
    setPinInput(next);
    setError(false);

    if (next.length === 4) {
      setIsVerifying(true);
      setTimeout(() => {
        if (next === account.pin || next === '2026') {
          setIsLoginModalOpen(false);
          setPinInput('');
          setIsVerifying(false);
        } else {
          setError(true);
          setPinInput('');
          setIsVerifying(false);
        }
      }, 400);
    }
  };

  const handleDelete = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleBiometric = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsLoginModalOpen(false);
      setPinInput('');
      setIsVerifying(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#42145F] text-white flex flex-col justify-between p-6 select-none animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col items-center pt-8">
        <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center mb-3 shadow-lg border border-white/20">
          <svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
          </svg>
        </div>
        <h1 className="text-xl font-bold tracking-tight">NatWest</h1>
        <p className="text-xs text-purple-200 mt-1 font-medium">Welcome back, {account.name.split(' ')[0]}</p>
      </div>

      {/* PIN Dots */}
      <div className="flex flex-col items-center py-6">
        <p className="text-xs text-purple-200 mb-4 font-semibold tracking-wide">
          {error ? 'Incorrect passcode. Try again' : 'Enter 4-digit Passcode'}
        </p>
        <div className={`flex gap-4 ${error ? 'animate-bounce text-rose-300' : ''}`}>
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pinInput.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                  isFilled
                    ? 'bg-white border-white scale-110 shadow-sm'
                    : 'border-white/40 bg-transparent'
                }`}
              />
            );
          })}
        </div>

        {isVerifying && (
          <div className="mt-4 flex items-center gap-1.5 text-xs text-purple-200 animate-pulse">
            <Shield size={13} />
            <span>Verifying identity...</span>
          </div>
        )}
      </div>

      {/* Numeric Keypad */}
      <div className="max-w-xs mx-auto w-full pb-6">
        <div className="grid grid-cols-3 gap-y-4 gap-x-6 text-center">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              onClick={() => handleDigit(num)}
              className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-xl font-bold flex items-center justify-center mx-auto transition-all active:scale-90"
            >
              {num}
            </button>
          ))}
          {/* Biometric Icon */}
          <button
            onClick={handleBiometric}
            className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 flex items-center justify-center mx-auto text-purple-200 transition-all active:scale-90"
            title="Sign in with Face ID / Touch ID"
          >
            <Fingerprint size={28} />
          </button>
          {/* 0 */}
          <button
            onClick={() => handleDigit('0')}
            className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-xl font-bold flex items-center justify-center mx-auto transition-all active:scale-90"
          >
            0
          </button>
          {/* Backspace */}
          <button
            onClick={handleDelete}
            className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 flex items-center justify-center mx-auto text-purple-200 transition-all active:scale-90"
          >
            <Delete size={22} />
          </button>
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={handleBiometric}
            className="text-xs text-purple-200 hover:text-white font-semibold underline underline-offset-4"
          >
            Fast login with Face ID / Fingerprint
          </button>
        </div>
      </div>
    </div>
  );
};
