import React from 'react';
import { CreditCard, PiggyBank, Landmark, ShieldCheck, Plane, ChevronRight, Sparkles } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const ApplyScreen: React.FC = () => {
  const { setIsAdminOpen } = useBanking();

  const products = [
    {
      title: 'Digital Regular Saver',
      desc: 'Earn 6.17% AER / 6.00% gross p.a. on your first £5,000.',
      icon: PiggyBank,
      color: 'bg-emerald-50 text-emerald-600',
      badge: 'Popular',
    },
    {
      title: 'Reward Credit Card',
      desc: 'Earn 1% back at UK supermarkets, 0.25% elsewhere.',
      icon: CreditCard,
      color: 'bg-purple-50 text-[#42145F]',
      badge: 'Offer',
    },
    {
      title: 'Personal Loan',
      desc: 'Borrow £1,000 to £50,000 with personalized rates.',
      icon: Landmark,
      color: 'bg-blue-50 text-blue-600',
    },
    {
      title: 'Travel Account & Currency',
      desc: 'Zero foreign transaction fees on international spending.',
      icon: Plane,
      color: 'bg-amber-50 text-amber-600',
    },
    {
      title: 'Financial Health Check',
      desc: 'Get tailored recommendations from a NatWest expert.',
      icon: ShieldCheck,
      color: 'bg-rose-50 text-rose-600',
    },
  ];

  return (
    <div className="px-4 py-4 pb-28 max-w-md mx-auto">
      <div className="mb-4">
        <h1 className="text-xl font-bold text-gray-900 tracking-tight">Explore Products</h1>
        <p className="text-xs text-gray-500">Apply for accounts, loans, and credit cards</p>
      </div>

      {/* Hero Banner */}
      <div
        onClick={() => setIsAdminOpen(true)}
        className="bg-gradient-to-r from-[#42145F] to-purple-800 rounded-3xl p-5 text-white mb-5 shadow-sm relative overflow-hidden cursor-pointer"
      >
        <div className="relative z-10">
          <span className="inline-flex items-center gap-1 bg-white/20 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase mb-2">
            <Sparkles size={11} /> Customize Everything
          </span>
          <h3 className="text-base font-bold">Make This App Your Own</h3>
          <p className="text-xs text-purple-200 mt-1 max-w-[240px]">
            Change names, balances, sort codes, account numbers, and add custom transactions in 1 click.
          </p>
          <button className="mt-3 bg-white text-[#42145F] px-4 py-1.5 rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-transform">
            Open Settings & Admin
          </button>
        </div>
      </div>

      {/* Products List */}
      <div className="space-y-2.5">
        {products.map((p, i) => {
          const Icon = p.icon;
          return (
            <div
              key={i}
              onClick={() => alert(`Applied for ${p.title}! Under review.`)}
              className="bg-white rounded-2xl p-4 border border-gray-100 shadow-2xs flex items-center justify-between hover:shadow-sm active:scale-99 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3.5">
                <div className={`w-10 h-10 rounded-xl ${p.color} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-gray-900">{p.title}</h4>
                    {p.badge && (
                      <span className="text-[9px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">
                        {p.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-gray-500 mt-0.5 leading-snug">{p.desc}</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-gray-300 flex-shrink-0 ml-2" />
            </div>
          );
        })}
      </div>
    </div>
  );
};
