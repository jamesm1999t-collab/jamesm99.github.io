import React, { useState } from 'react';
import { Send, Bot, PhoneCall, ShieldAlert, Sparkles, User } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const HelpScreen: React.FC = () => {
  const { account } = useBanking();
  const [messages, setMessages] = useState<{ sender: 'cora' | 'user'; text: string }[]>([
    {
      sender: 'cora',
      text: `Hello ${account.name.split(' ')[0]}! I'm Cora, your 24/7 NatWest virtual assistant. How can I help you today?`,
    },
  ]);
  const [input, setInput] = useState('');

  const quickQuestions = [
    'How do I freeze my card?',
    'What is my current balance?',
    'How do I view my PIN?',
    'What is my sort code & account number?',
  ];

  const handleSend = (text: string) => {
    if (!text.trim()) return;

    const userMsg = text.trim();
    setMessages((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setInput('');

    setTimeout(() => {
      let reply = "I can help with that. You can manage your account settings or card controls anytime from the Home tab or by tapping the 'Customize' button!";
      const lower = userMsg.toLowerCase();

      if (lower.includes('balance')) {
        reply = `Your available Current Account balance is £${account.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}. You also have £${account.savingsBalance.toLocaleString('en-GB', { minimumFractionDigits: 2 })} in your Digital Regular Saver.`;
      } else if (lower.includes('freeze') || lower.includes('card')) {
        reply = "You can instantly freeze or unfreeze your debit card by tapping 'Manage Cards' on the Home tab. Freezing blocks all new purchases while keeping direct debits active.";
      } else if (lower.includes('pin')) {
        reply = `Your current security PIN is set to ${account.pin}. You can also view or change it in the Customize / Admin panel.`;
      } else if (lower.includes('sort code') || lower.includes('account number')) {
        reply = `Your NatWest Sort Code is ${account.sortCode} and your Account Number is ${account.accountNumber}.`;
      }

      setMessages((prev) => [...prev, { sender: 'cora', text: reply }]);
    }, 600);
  };

  return (
    <div className="px-4 py-4 pb-28 max-w-md mx-auto flex flex-col h-[calc(100vh-140px)]">
      {/* Header */}
      <div className="flex items-center gap-3 pb-3 border-b border-gray-100 flex-shrink-0">
        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#42145F] to-purple-600 text-white flex items-center justify-center shadow-sm">
          <Bot size={20} />
        </div>
        <div>
          <h2 className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
            <span>Chat with Cora</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </h2>
          <p className="text-[10px] text-gray-400">NatWest Virtual Assistant · 24/7</p>
        </div>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto py-4 space-y-3">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-2 ${m.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs flex-shrink-0 ${
                m.sender === 'user' ? 'bg-[#42145F] text-white' : 'bg-purple-100 text-[#42145F]'
              }`}
            >
              {m.sender === 'user' ? <User size={13} /> : <Sparkles size={13} />}
            </div>
            <div
              className={`max-w-[75%] rounded-2xl p-3 text-xs leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-[#42145F] text-white rounded-tr-xs'
                  : 'bg-white border border-gray-100 text-gray-800 rounded-tl-xs shadow-2xs'
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
      </div>

      {/* Quick Prompts */}
      <div className="flex gap-1.5 overflow-x-auto py-2 scrollbar-none flex-shrink-0">
        {quickQuestions.map((q, i) => (
          <button
            key={i}
            onClick={() => handleSend(q)}
            className="bg-white hover:bg-gray-50 border border-gray-200 text-gray-600 rounded-full px-3 py-1 text-[10px] font-medium whitespace-nowrap active:scale-95 transition-all shadow-2xs"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div className="pt-2 flex items-center gap-2 flex-shrink-0">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend(input)}
          placeholder="Ask Cora a question..."
          className="flex-1 bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-[#42145F] shadow-2xs"
        />
        <button
          onClick={() => handleSend(input)}
          className="w-9 h-9 rounded-xl bg-[#42145F] text-white flex items-center justify-center hover:bg-purple-900 active:scale-95 transition-all shadow-xs"
        >
          <Send size={15} />
        </button>
      </div>

      {/* Emergency Contact Strip */}
      <div className="mt-3 pt-2 border-t border-gray-100 flex items-center justify-between text-[10px] text-gray-400 flex-shrink-0">
        <span className="flex items-center gap-1">
          <ShieldAlert size={12} className="text-amber-500" /> Lost or stolen card? Call 03457 888 444
        </span>
        <button
          onClick={() => alert('Dialing NatWest Premier Customer Support: 0800 200 400')}
          className="text-[#42145F] font-semibold flex items-center gap-1 hover:underline"
        >
          <PhoneCall size={11} /> Call us
        </button>
      </div>
    </div>
  );
};
