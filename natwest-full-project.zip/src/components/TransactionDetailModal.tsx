import React from 'react';
import { useBanking } from '../context/BankingContext';
import { X, Trash2, Share2, Repeat, CheckCircle2 } from 'lucide-react';

export const TransactionDetailModal: React.FC = () => {
  const { selectedTransaction, setSelectedTransaction, deleteTransaction } = useBanking();

  if (!selectedTransaction) return null;

  const isIncome = selectedTransaction.type === 'in';
  const dateFormatted = new Date(selectedTransaction.date).toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const handleDelete = () => {
    if (confirm(`Delete this transaction for ${selectedTransaction.payeeName}?`)) {
      deleteTransaction(selectedTransaction.id);
      setSelectedTransaction(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-semibold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
            Transaction Receipt
          </span>
          <button
            onClick={() => setSelectedTransaction(null)}
            className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Amount & Payee Hero */}
        <div className="text-center py-4 border-b border-gray-100">
          <div
            className={`w-14 h-14 rounded-2xl mx-auto flex items-center justify-center font-bold text-lg mb-3 ${
              isIncome ? 'bg-emerald-100 text-emerald-800' : 'bg-[#42145F] text-white shadow-md'
            }`}
          >
            {selectedTransaction.payeeInitials}
          </div>
          <h2 className="text-base font-bold text-gray-900">{selectedTransaction.payeeName}</h2>
          <p
            className={`text-3xl font-black mt-1 tracking-tight ${
              isIncome ? 'text-emerald-600' : 'text-gray-900'
            }`}
          >
            {isIncome ? '+' : '-'}£
            {selectedTransaction.amount.toLocaleString('en-GB', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </p>
          <div className="flex items-center justify-center gap-1.5 mt-2 text-xs text-emerald-700 font-semibold">
            <CheckCircle2 size={13} />
            <span>Completed · Faster Payments</span>
          </div>
        </div>

        {/* Detail Breakdown */}
        <div className="py-4 space-y-3 text-xs border-b border-gray-100">
          <div className="flex justify-between">
            <span className="text-gray-400">Date & Time</span>
            <span className="font-semibold text-gray-800">{dateFormatted}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Category</span>
            <span className="font-semibold text-gray-800">{selectedTransaction.category}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Reference</span>
            <span className="font-semibold text-gray-800 font-mono">
              {selectedTransaction.reference || 'N/A'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Transaction ID</span>
            <span className="font-mono text-[10px] text-gray-400 truncate max-w-[200px]">
              {selectedTransaction.id}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-4 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => alert('Receipt copied to clipboard')}
              className="flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 active:scale-95 text-gray-700 py-2.5 rounded-xl text-xs font-semibold transition-all"
            >
              <Share2 size={14} />
              <span>Share Receipt</span>
            </button>
            <button
              onClick={() => alert('Setting up recurring payment...')}
              className="flex items-center justify-center gap-2 bg-purple-50 hover:bg-purple-100 active:scale-95 text-[#42145F] py-2.5 rounded-xl text-xs font-semibold transition-all"
            >
              <Repeat size={14} />
              <span>Repeat Payment</span>
            </button>
          </div>

          <button
            onClick={handleDelete}
            className="w-full flex items-center justify-center gap-2 bg-rose-50 hover:bg-rose-100 text-rose-600 py-2.5 rounded-xl text-xs font-semibold active:scale-95 transition-all"
          >
            <Trash2 size={14} />
            <span>Delete Transaction</span>
          </button>
        </div>
      </div>
    </div>
  );
};
