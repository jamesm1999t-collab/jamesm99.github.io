import React from 'react';
import { useBanking } from '../context/BankingContext';
import { ArrowUpRight, ArrowLeftRight, Banknote, FileText, CreditCard, Sparkles } from 'lucide-react';

export const QuickActions: React.FC = () => {
  const { setCurrentTab, setIsCardsModalOpen, setIsPotsModalOpen } = useBanking();

  const actions = [
    {
      id: 'pay',
      label: 'Pay & Transfer',
      icon: ArrowUpRight,
      color: 'bg-purple-50 text-[#42145F]',
      onClick: () => setCurrentTab('payments'),
    },
    {
      id: 'move',
      label: 'Move Money',
      icon: ArrowLeftRight,
      color: 'bg-blue-50 text-blue-700',
      onClick: () => setCurrentTab('payments'),
    },
    {
      id: 'cards',
      label: 'Manage Cards',
      icon: CreditCard,
      color: 'bg-emerald-50 text-emerald-700',
      onClick: () => setIsCardsModalOpen(true),
    },
    {
      id: 'pots',
      label: 'Savings Pots',
      icon: Sparkles,
      color: 'bg-amber-50 text-amber-700',
      onClick: () => setIsPotsModalOpen(true),
    },
    {
      id: 'cash',
      label: 'Get Cash',
      icon: Banknote,
      color: 'bg-rose-50 text-rose-700',
      onClick: () => alert('Emergency Get Cash Code: 839-201 (Valid for 3 hours at any NatWest ATM)'),
    },
    {
      id: 'statements',
      label: 'Statements',
      icon: FileText,
      color: 'bg-slate-50 text-slate-700',
      onClick: () => alert('Generating latest e-Statement for download...'),
    },
  ];

  return (
    <div className="px-4 py-2">
      <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2.5">Quick Actions</h2>
      <div className="grid grid-cols-3 gap-2.5">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.id}
              onClick={act.onClick}
              className="bg-white rounded-xl p-3 border border-gray-100 shadow-xs flex flex-col items-center justify-center text-center hover:bg-gray-50 active:scale-95 transition-all"
            >
              <div className={`w-9 h-9 rounded-full ${act.color} flex items-center justify-center mb-1.5`}>
                <Icon size={18} strokeWidth={2} />
              </div>
              <span className="text-[11px] font-semibold text-gray-800 leading-tight">{act.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
