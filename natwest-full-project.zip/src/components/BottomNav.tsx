import React from 'react';
import { useBanking } from '../context/BankingContext';
import { TabType } from '../types';
import { Home, HelpCircle, ArrowLeftRight, PieChart, LayoutGrid } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { currentTab, setCurrentTab } = useBanking();

  const navItems: { id: TabType; label: string; icon: React.FC<{ size?: number; className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'help', label: 'Help', icon: HelpCircle },
    { id: 'payments', label: 'Payments', icon: ArrowLeftRight },
    { id: 'insights', label: 'Insights', icon: PieChart },
    { id: 'apply', label: 'Apply', icon: LayoutGrid },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-200/80 px-2 py-1.5 shadow-lg select-none">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
                isActive ? 'text-[#42145F] font-bold scale-105' : 'text-gray-400 hover:text-gray-600 font-medium'
              }`}
            >
              <div className="relative">
                <Icon size={20} className={isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'} />
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#42145F] absolute -bottom-1 left-1/2 -translate-x-1/2" />
                )}
              </div>
              <span className="text-[10px] mt-1 leading-none">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
