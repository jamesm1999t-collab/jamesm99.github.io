// NatWest Admin Helper (Invisible keyboard listener only)

function triggerAdminMode() {
  // Method 1: Triple-click the account card NatWest logo (Home or Payments screen)
  const accountCard = document.querySelector('[data-testid="account-card"]');
  if (accountCard) {
    const logoContainer =
      accountCard.querySelector('.w-7')?.parentElement ||
      accountCard.querySelector('h3')?.parentElement ||
      accountCard;

    if (logoContainer) {
      for (let i = 0; i < 3; i++) {
        setTimeout(() => {
          logoContainer.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        }, i * 60);
      }
      return true;
    }
  }

  // Method 2: On Apply tab, click Savings 3 times
  const applySavingsButton = Array.from(document.querySelectorAll('button')).find((b) =>
    b.textContent?.includes('Savings')
  );
  if (applySavingsButton) {
    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        applySavingsButton.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      }, i * 60);
    }
    return true;
  }

  // Method 3: If on login screen, simulate PIN entry 2026
  const pinInput = document.querySelector('input[type="password"]');
  if (pinInput) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      'value'
    )?.set;
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(pinInput, '2026');
      pinInput.dispatchEvent(new Event('input', { bubbles: true }));
      pinInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    }
  }

  return false;
}

// Clean up any existing floating button if present
const existing = document.getElementById('natwest-admin-trigger-root');
if (existing) {
  existing.remove();
}

// Keep invisible keyboard shortcut: Alt+A or Ctrl+Shift+A
window.addEventListener('keydown', (e) => {
  if ((e.altKey && e.key.toLowerCase() === 'a') || (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a')) {
    e.preventDefault();
    triggerAdminMode();
  }
});

export { triggerAdminMode };
