import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Account, Transaction, Payee, SavingsPot, TabType } from '../types';
import { DEFAULT_ACCOUNT, INITIAL_PAYEES, INITIAL_POTS, INITIAL_TRANSACTIONS } from '../data/initialData';

interface BankingContextType {
  account: Account;
  accounts: Account[];
  transactions: Transaction[];
  payees: Payee[];
  pots: SavingsPot[];
  currentTab: TabType;
  isAdminOpen: boolean;
  isLoginModalOpen: boolean;
  isCardsModalOpen: boolean;
  isPotsModalOpen: boolean;
  selectedTransaction: Transaction | null;
  setCurrentTab: (tab: TabType) => void;
  setIsAdminOpen: (open: boolean) => void;
  setIsLoginModalOpen: (open: boolean) => void;
  setIsCardsModalOpen: (open: boolean) => void;
  setIsPotsModalOpen: (open: boolean) => void;
  setSelectedTransaction: (tx: Transaction | null) => void;
  updateAccount: (updates: Partial<Account>) => void;
  updateBalance: (delta: number) => void;
  setExactBalance: (newBalance: number) => void;
  addTransaction: (tx: Omit<Transaction, 'id' | 'accountId'>) => void;
  deleteTransaction: (id: string) => void;
  addPayee: (payee: Omit<Payee, 'id'>) => void;
  deletePayee: (id: string) => void;
  transferMoney: (toAccountNumber: string, toSortCode: string, amount: number, reference: string, recipientName: string) => Promise<boolean>;
  updatePot: (id: string, delta: number) => void;
  switchAccount: (account: Account) => void;
  resetToDefaults: () => void;
}

const BankingContext = createContext<BankingContextType | undefined>(undefined);

export const BankingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [accounts, setAccounts] = useState<Account[]>([DEFAULT_ACCOUNT]);
  const [account, setAccount] = useState<Account>(() => {
    try {
      const saved = localStorage.getItem('natwest_user_account');
      return saved ? JSON.parse(saved) : DEFAULT_ACCOUNT;
    } catch {
      return DEFAULT_ACCOUNT;
    }
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('natwest_transactions');
      return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
    } catch {
      return INITIAL_TRANSACTIONS;
    }
  });

  const [payees, setPayees] = useState<Payee[]>(() => {
    try {
      const saved = localStorage.getItem('natwest_payees');
      return saved ? JSON.parse(saved) : INITIAL_PAYEES;
    } catch {
      return INITIAL_PAYEES;
    }
  });

  const [pots, setPots] = useState<SavingsPot[]>(() => {
    try {
      const saved = localStorage.getItem('natwest_pots');
      return saved ? JSON.parse(saved) : INITIAL_POTS;
    } catch {
      return INITIAL_POTS;
    }
  });

  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isCardsModalOpen, setIsCardsModalOpen] = useState(false);
  const [isPotsModalOpen, setIsPotsModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('natwest_user_account', JSON.stringify(account));
    } catch (e) {
      console.error(e);
    }
  }, [account]);

  useEffect(() => {
    try {
      localStorage.setItem('natwest_transactions', JSON.stringify(transactions));
    } catch (e) {
      console.error(e);
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem('natwest_payees', JSON.stringify(payees));
    } catch (e) {
      console.error(e);
    }
  }, [payees]);

  useEffect(() => {
    try {
      localStorage.setItem('natwest_pots', JSON.stringify(pots));
    } catch (e) {
      console.error(e);
    }
  }, [pots]);

  // Sync with backend API if available
  useEffect(() => {
    async function fetchServerData() {
      try {
        const res = await fetch('/api/admin/accounts');
        if (res.ok) {
          const list = await res.json();
          if (Array.isArray(list) && list.length > 0) {
            setAccounts(list);
            const found = list.find((a: Account) => a.id === account.id) || list[0];
            setAccount(found);

            const txRes = await fetch(`/api/transactions/${found.id}`);
            if (txRes.ok) {
              const txList = await txRes.json();
              if (Array.isArray(txList) && txList.length > 0) {
                setTransactions(txList);
              }
            }
          }
        }
      } catch {
        // Fallback gracefully to local state
      }
    }
    fetchServerData();
  }, []);

  const updateAccount = (updates: Partial<Account>) => {
    setAccount((prev) => {
      const updated = { ...prev, ...updates };
      // Also update in accounts list
      setAccounts((list) => list.map((a) => (a.id === updated.id ? updated : a)));

      // Sync to backend
      fetch(`/api/admin/accounts/${updated.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      }).catch(() => {});

      return updated;
    });
  };

  const updateBalance = (delta: number) => {
    setAccount((prev) => {
      const newBal = Math.max(0, +(prev.balance + delta).toFixed(2));
      const updated = { ...prev, balance: newBal };
      fetch(`/api/admin/accounts/${prev.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ balance: newBal }),
      }).catch(() => {});
      return updated;
    });
  };

  const setExactBalance = (newBalance: number) => {
    setAccount((prev) => {
      const val = +(newBalance).toFixed(2);
      const updated = { ...prev, balance: val };
      fetch(`/api/admin/accounts/${prev.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ balance: val }),
      }).catch(() => {});
      return updated;
    });
  };

  const addTransaction = (tx: Omit<Transaction, 'id' | 'accountId'>) => {
    const newTx: Transaction = {
      ...tx,
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      accountId: account.id,
      date: tx.date || new Date().toISOString(),
      currency: tx.currency || 'GBP',
      currencySymbol: tx.currencySymbol || '£',
    };

    setTransactions((prev) => [newTx, ...prev]);

    // Update balance accordingly
    if (newTx.type === 'out') {
      updateBalance(-newTx.amount);
    } else {
      updateBalance(newTx.amount);
    }

    // Sync to backend
    fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTx),
    }).catch(() => {});
  };

  const deleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    fetch(`/api/transactions/${id}`, { method: 'DELETE' }).catch(() => {});
  };

  const addPayee = (payeeData: Omit<Payee, 'id'>) => {
    const newPayee: Payee = {
      ...payeeData,
      id: `p-${Date.now()}`,
    };
    setPayees((prev) => [newPayee, ...prev]);
  };

  const deletePayee = (id: string) => {
    setPayees((prev) => prev.filter((p) => p.id !== id));
  };

  const transferMoney = async (
    toAccountNumber: string,
    toSortCode: string,
    amount: number,
    reference: string,
    recipientName: string
  ): Promise<boolean> => {
    if (amount <= 0 || amount > account.balance + account.overdraftLimit) {
      return false;
    }

    addTransaction({
      payeeName: recipientName.toUpperCase(),
      payeeInitials: recipientName.slice(0, 2).toUpperCase(),
      amount,
      type: 'out',
      date: new Date().toISOString(),
      category: 'Shopping',
      reference: reference || 'TRANSFER',
      accountNumber: toAccountNumber,
      sortCode: toSortCode,
    });

    try {
      await fetch('/api/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromAccountNumber: account.accountNumber,
          fromSortCode: account.sortCode,
          toAccountNumber,
          toSortCode,
          amount,
          reference,
          senderName: account.name,
        }),
      });
    } catch {}

    return true;
  };

  const updatePot = (id: string, delta: number) => {
    setPots((prev) =>
      prev.map((pot) => {
        if (pot.id === id) {
          const newCurrent = Math.max(0, +(pot.current + delta).toFixed(2));
          return { ...pot, current: newCurrent };
        }
        return pot;
      })
    );
  };

  const switchAccount = (newAcc: Account) => {
    setAccount(newAcc);
  };

  const resetToDefaults = () => {
    setAccount(DEFAULT_ACCOUNT);
    setTransactions(INITIAL_TRANSACTIONS);
    setPayees(INITIAL_PAYEES);
    setPots(INITIAL_POTS);
    localStorage.removeItem('natwest_user_account');
    localStorage.removeItem('natwest_transactions');
    localStorage.removeItem('natwest_payees');
    localStorage.removeItem('natwest_pots');
  };

  return (
    <BankingContext.Provider
      value={{
        account,
        accounts,
        transactions,
        payees,
        pots,
        currentTab,
        isAdminOpen,
        isLoginModalOpen,
        isCardsModalOpen,
        isPotsModalOpen,
        selectedTransaction,
        setCurrentTab,
        setIsAdminOpen,
        setIsLoginModalOpen,
        setIsCardsModalOpen,
        setIsPotsModalOpen,
        setSelectedTransaction,
        updateAccount,
        updateBalance,
        setExactBalance,
        addTransaction,
        deleteTransaction,
        addPayee,
        deletePayee,
        transferMoney,
        updatePot,
        switchAccount,
        resetToDefaults,
      }}
    >
      {children}
    </BankingContext.Provider>
  );
};

export const useBanking = () => {
  const context = useContext(BankingContext);
  if (!context) {
    throw new Error('useBanking must be used within a BankingProvider');
  }
  return context;
};
