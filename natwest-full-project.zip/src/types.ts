export interface Account {
  id: string;
  name: string;
  accountName: string;
  initials: string;
  accountNumber: string;
  sortCode: string;
  balance: number;
  overdraftLimit: number;
  savingsAccountNumber: string;
  savingsSortCode: string;
  savingsBalance: number;
  linkedAccountNumber: string;
  linkedSortCode: string;
  linkedBalance: number;
  customerNumber: string;
  address: string;
  phone: string;
  email: string;
  pin: string;
  slug: string;
}

export interface Transaction {
  id: string;
  accountId: string;
  payeeName: string;
  payeeInitials: string;
  amount: number;
  date: string; // ISO date string
  accountNumber?: string | null;
  sortCode?: string | null;
  reference?: string;
  type: 'in' | 'out';
  category: 'Shopping' | 'Groceries' | 'Bills' | 'Income' | 'Entertainment' | 'Eating Out' | 'Travel' | 'General';
  currency?: string;
  currencySymbol?: string;
  isInternational?: boolean;
  iban?: string | null;
  swiftBic?: string | null;
  isPending?: boolean;
  logoUrl?: string;
}

export interface Payee {
  id: string;
  name: string;
  initials: string;
  accountNumber: string;
  sortCode: string;
  isFavourite?: boolean;
}

export interface SavingsPot {
  id: string;
  name: string;
  target: number;
  current: number;
  color: string;
  icon: string;
}

export type TabType = 'home' | 'help' | 'payments' | 'insights' | 'apply';
