import React from 'react';
import { BankingProvider, useBanking } from './context/BankingContext';
import { Header } from './components/Header';
import { AccountCards } from './components/AccountCards';
import { QuickActions } from './components/QuickActions';
import { TransactionList } from './components/TransactionList';
import { PaymentsScreen } from './components/PaymentsScreen';
import { HelpScreen } from './components/HelpScreen';
import { InsightsScreen } from './components/InsightsScreen';
import { ApplyScreen } from './components/ApplyScreen';
import { BottomNav } from './components/BottomNav';
import { TransactionDetailModal } from './components/TransactionDetailModal';
import { CardsModal } from './components/CardsModal';
import { PotsModal } from './components/PotsModal';
import { AdminModal } from './components/AdminModal';
import { LoginModal } from './components/LoginModal';

const MainLayout: React.FC = () => {
  const { currentTab } = useBanking();

  return (
    <div className="min-h-screen bg-[#F4F1F6] flex justify-center text-gray-900 font-sans antialiased">
      {/* Mobile Frame Container */}
      <div className="w-full max-w-md bg-white min-h-screen shadow-2xl flex flex-col relative overflow-x-hidden pb-12">
        <Header />

        <main className="flex-1 overflow-y-auto">
          {currentTab === 'home' && (
            <div className="space-y-4 pt-1 animate-in fade-in duration-200">
              <AccountCards />
              <QuickActions />
              <TransactionList />
            </div>
          )}

          {currentTab === 'payments' && <PaymentsScreen />}
          {currentTab === 'help' && <HelpScreen />}
          {currentTab === 'insights' && <InsightsScreen />}
          {currentTab === 'apply' && <ApplyScreen />}
        </main>

        <BottomNav />

        {/* Modals & Dialogs */}
        <TransactionDetailModal />
        <CardsModal />
        <PotsModal />
        <AdminModal />
        <LoginModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <BankingProvider>
      <MainLayout />
    </BankingProvider>
  );
}
