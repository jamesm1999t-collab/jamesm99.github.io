(function () {
  var STORAGE_KEY = 'nw_static_db_v1';
  var memDb = null;

  var UK_DAILY_MERCHANTS = [
    { payeeName: 'TESCO EXPRESS', initials: 'TE', category: 'Groceries', reference: 'Contactless Card', min: 4.5, max: 68.9 },
    { payeeName: 'PRET A MANGER', initials: 'PA', category: 'Eating Out', reference: 'Apple Pay', min: 3.8, max: 18.9 },
    { payeeName: 'COSTA COFFEE', initials: 'CC', category: 'Eating Out', reference: 'Contactless Card', min: 3.1, max: 14.4 },
    { payeeName: 'SAINSBURYS LOCAL', initials: 'SL', category: 'Groceries', reference: 'Card Payment', min: 5.2, max: 84.8 },
    { payeeName: 'GREGGS', initials: 'GR', category: 'Eating Out', reference: 'Contactless Card', min: 2.6, max: 11.8 },
    { payeeName: 'BOOTS UK', initials: 'BO', category: 'Health', reference: 'Card Payment', min: 4.9, max: 62.5 },
    { payeeName: 'MARKS & SPENCER', initials: 'MS', category: 'Shopping', reference: 'Apple Pay', min: 8.5, max: 88.6 },
    { payeeName: 'WAITROSE & PARTNERS', initials: 'WP', category: 'Groceries', reference: 'Contactless Card', min: 7.4, max: 94.9 },
    { payeeName: 'CO-OP FOOD', initials: 'CF', category: 'Groceries', reference: 'Card Payment', min: 4.1, max: 54.2 },
    { payeeName: 'TFL TRAVEL CH', initials: 'TF', category: 'Transport', reference: 'Contactless Card', min: 2.8, max: 24.5 },
    { payeeName: 'CAFFE NERO', initials: 'CN', category: 'Eating Out', reference: 'Apple Pay', min: 3.3, max: 15.2 },
    { payeeName: 'ALDI STORES', initials: 'AL', category: 'Groceries', reference: 'Card Payment', min: 9.5, max: 79.5 },
    { payeeName: 'LIDL GB', initials: 'LI', category: 'Groceries', reference: 'Card Payment', min: 8.2, max: 73.9 },
    { payeeName: 'WHSMITH', initials: 'WH', category: 'Shopping', reference: 'Contactless Card', min: 3.5, max: 31.9 },
    { payeeName: 'UBER TRIP', initials: 'UB', category: 'Transport', reference: 'Card Payment', min: 6.8, max: 45.4 },
    { payeeName: 'DELIVEROO LONDON', initials: 'DE', category: 'Eating Out', reference: 'Online Purchase', min: 11.5, max: 59.8 },
    { payeeName: 'ASDA EXPRESS', initials: 'AS', category: 'Groceries', reference: 'Contactless Card', min: 4.7, max: 76.4 },
    { payeeName: 'SUPERDRUG', initials: 'SU', category: 'Health', reference: 'Card Payment', min: 4.2, max: 46.8 },
    { payeeName: 'LEON RESTAURANTS', initials: 'LE', category: 'Eating Out', reference: 'Apple Pay', min: 6.9, max: 24.5 },
    { payeeName: 'ROYAL MAIL', initials: 'RM', category: 'Services', reference: 'Card Payment', min: 3.2, max: 29.6 },
    { payeeName: 'ARGOS', initials: 'AR', category: 'Shopping', reference: 'Card Payment', min: 9.9, max: 96.5 },
    { payeeName: 'HOLLAND & BARRETT', initials: 'HB', category: 'Health', reference: 'Contactless Card', min: 5.5, max: 49.9 },
    { payeeName: 'ITSU', initials: 'IT', category: 'Eating Out', reference: 'Contactless Card', min: 6.4, max: 21.8 },
    { payeeName: 'SHELL UK', initials: 'SH', category: 'Transport', reference: 'Card Payment', min: 15.0, max: 89.2 },
    { payeeName: 'BP CONNECT UK', initials: 'BP', category: 'Transport', reference: 'Contactless Card', min: 18.0, max: 87.5 },
    { payeeName: 'JOHN LEWIS', initials: 'JL', category: 'Shopping', reference: 'Apple Pay', min: 14.0, max: 95.0 },
    { payeeName: 'CURRYS', initials: 'CU', category: 'Shopping', reference: 'Card Payment', min: 19.99, max: 98.5 },
    { payeeName: 'PRIMARK UK', initials: 'PR', category: 'Shopping', reference: 'Contactless Card', min: 12.0, max: 68.0 },
    { payeeName: 'NEXT RETAIL', initials: 'NR', category: 'Shopping', reference: 'Card Payment', min: 16.0, max: 89.0 },
    { payeeName: 'MORRISONS', initials: 'MO', category: 'Groceries', reference: 'Contactless Card', min: 11.4, max: 82.3 },
    { payeeName: 'NANDOS UK', initials: 'NA', category: 'Eating Out', reference: 'Apple Pay', min: 13.5, max: 52.4 },
    { payeeName: 'WAGAMAMA', initials: 'WA', category: 'Eating Out', reference: 'Contactless Card', min: 14.8, max: 58.6 },
    { payeeName: 'JUST EAT UK', initials: 'JE', category: 'Eating Out', reference: 'Online Purchase', min: 12.4, max: 46.9 },
    { payeeName: 'TRAINLINE UK', initials: 'TR', category: 'Transport', reference: 'Online Purchase', min: 9.8, max: 84.5 },
    { payeeName: 'B&Q UK', initials: 'BQ', category: 'Shopping', reference: 'Card Payment', min: 11.0, max: 92.4 },
    { payeeName: 'AMAZON UK', initials: 'AM', category: 'Shopping', reference: 'Online Purchase', min: 7.99, max: 94.99 },
    { payeeName: 'EE LIMITED', initials: 'EE', category: 'Bills', reference: 'Direct Debit', min: 18.0, max: 54.0 },
    { payeeName: 'THAMES WATER', initials: 'TW', category: 'Bills', reference: 'Direct Debit', min: 24.0, max: 69.5 },
  ];

  function getUKDateStr(date) {
    try {
      return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Europe/London',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(date);
    } catch (e) {
      return date.toISOString().slice(0, 10);
    }
  }

  function addDaysToDateStr(dateStr, deltaDays) {
    var parts = dateStr.split('-').map(Number);
    var dt = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2] + deltaDays, 12, 0, 0));
    return dt.toISOString().slice(0, 10);
  }

  function hashSeed(input) {
    var h = 2166136261;
    for (var i = 0; i < input.length; i++) {
      h ^= input.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function getScheduledTimesForDay(accountId, dateStr) {
    var parts = dateStr.split('-').map(Number);
    var seed = hashSeed(accountId + ':' + dateStr);
    var slot1Hour = 8 + (seed % 5);
    var slot1Min = (seed >>> 4) % 60;
    var slot1Sec = (seed >>> 10) % 60;
    var slot1 = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], slot1Hour, slot1Min, slot1Sec));
    var extraMins = (seed >>> 16) % 15;
    var slot2 = new Date(slot1.getTime() + (5 * 60 + extraMins) * 60 * 1000);
    return [slot1, slot2];
  }

  function generateUKTransactionForSlot(account, dateStr, slot, txTime, excludePayeeName) {
    var idx = Math.floor(Math.random() * UK_DAILY_MERCHANTS.length);
    if (excludePayeeName && UK_DAILY_MERCHANTS[idx].payeeName === excludePayeeName) {
      idx = (idx + 1) % UK_DAILY_MERCHANTS.length;
    }
    var merchant = UK_DAILY_MERCHANTS[idx];
    var rawAmt = merchant.min + Math.random() * (merchant.max - merchant.min);
    var amount = Math.min(99.99, Math.round(rawAmt * 100) / 100);
    return {
      id: 'auto-' + account.id + '-' + dateStr + '-' + slot,
      accountId: account.id,
      payeeName: merchant.payeeName,
      payeeInitials: merchant.initials,
      amount: amount,
      date: txTime.toISOString(),
      accountNumber: null,
      sortCode: null,
      reference: merchant.reference,
      type: 'out',
      category: merchant.category,
      currency: 'GBP',
      currencySymbol: '£',
      isInternational: false,
      iban: null,
      swiftBic: null,
      isPending: false,
    };
  }

  function ensureDailyTransactions(db, backfillDays) {
    if (backfillDays === undefined) backfillDays = 55;
    if (!db.autoGeneratedDays) db.autoGeneratedDays = {};
    var now = new Date();
    var todayStr = getUKDateStr(now);
    var changed = false;

    for (var i = 0; i < db.accounts.length; i++) {
      var account = db.accounts[i];
      if (!db.autoGeneratedDays[account.id]) db.autoGeneratedDays[account.id] = [];
      var generatedSet = new Set(db.autoGeneratedDays[account.id]);

      for (var offset = backfillDays; offset >= 1; offset--) {
        var dateStr = addDaysToDateStr(todayStr, -offset);
        if (generatedSet.has(dateStr)) continue;
        var times = getScheduledTimesForDay(account.id, dateStr);
        var id1 = 'auto-' + account.id + '-' + dateStr + '-1';
        var id2 = 'auto-' + account.id + '-' + dateStr + '-2';

        var tx1 = db.transactions.find(function (t) { return t.id === id1; });
        if (!tx1) {
          tx1 = generateUKTransactionForSlot(account, dateStr, 1, times[0]);
          db.transactions.unshift(tx1);
          changed = true;
        }
        if (!db.transactions.some(function (t) { return t.id === id2; })) {
          var tx2 = generateUKTransactionForSlot(account, dateStr, 2, times[1], tx1.payeeName);
          db.transactions.unshift(tx2);
          changed = true;
        }
        db.autoGeneratedDays[account.id].push(dateStr);
        generatedSet.add(dateStr);
        changed = true;
      }

      if (!generatedSet.has(todayStr)) {
        var todayTimes = getScheduledTimesForDay(account.id, todayStr);
        var tid1 = 'auto-' + account.id + '-' + todayStr + '-1';
        var tid2 = 'auto-' + account.id + '-' + todayStr + '-2';
        var slot1Key = todayStr + ':1';
        var slot2Key = todayStr + ':2';

        var t1 = db.transactions.find(function (t) { return t.id === tid1; });
        if (!t1 && !generatedSet.has(slot1Key) && now.getTime() >= todayTimes[0].getTime()) {
          t1 = generateUKTransactionForSlot(account, todayStr, 1, todayTimes[0]);
          db.transactions.unshift(t1);
          if (account.balance >= t1.amount) {
            account.balance = Math.round((account.balance - t1.amount) * 100) / 100;
          }
          db.autoGeneratedDays[account.id].push(slot1Key);
          generatedSet.add(slot1Key);
          changed = true;
        }

        var t2 = db.transactions.find(function (t) { return t.id === tid2; });
        var earliestSlot2Ms = t1
          ? Math.max(todayTimes[1].getTime(), new Date(t1.date).getTime() + 5 * 60 * 60 * 1000)
          : todayTimes[1].getTime();

        if (t1 && !t2 && !generatedSet.has(slot2Key) && now.getTime() >= earliestSlot2Ms) {
          t2 = generateUKTransactionForSlot(account, todayStr, 2, new Date(earliestSlot2Ms), t1.payeeName);
          db.transactions.unshift(t2);
          if (account.balance >= t2.amount) {
            account.balance = Math.round((account.balance - t2.amount) * 100) / 100;
          }
          db.autoGeneratedDays[account.id].push(slot2Key);
          generatedSet.add(slot2Key);
          changed = true;
        }

        if (
          db.transactions.some(function (t) { return t.id === tid1; }) &&
          db.transactions.some(function (t) { return t.id === tid2; })
        ) {
          db.autoGeneratedDays[account.id].push(todayStr);
          generatedSet.add(todayStr);
          changed = true;
        }
      }

      db.autoGeneratedDays[account.id].sort();
    }

    if (changed) {
      db.transactions.sort(function (a, b) {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });
    }
    return changed;
  }

  function createInitialDb() {
    var now = Date.now();
    var db = {
      accounts: [
        {
          id: 'natwest-main-001',
          name: 'JAMES M',
          accountName: 'JAMES M / CUR',
          initials: 'JM',
          accountNumber: '89026813',
          sortCode: '60-12-34',
          balance: 18060.18,
          overdraftLimit: 1000,
          savingsAccountNumber: '09913751',
          savingsSortCode: '60-12-35',
          savingsBalance: 23850,
          linkedAccountNumber: '87341693',
          linkedSortCode: '04-00-04',
          linkedBalance: 5487.91,
          customerNumber: '2309990043',
          address: '14 St. James Square\nLondon\nSW1Y 4LE',
          phone: '+44 7700 900123',
          email: 'james.m@email.com',
          pin: '2026',
          slug: 'james',
        },
      ],
      transactions: [
        {
          id: 'tx-1',
          accountId: 'natwest-main-001',
          payeeName: 'TESCO STORES',
          payeeInitials: 'TE',
          amount: 47.82,
          type: 'out',
          date: new Date(now - 2 * 3600000).toISOString(),
          category: 'Groceries',
          reference: 'Contactless Card',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-2',
          accountId: 'natwest-main-001',
          payeeName: 'SPOTIFY UK',
          payeeInitials: 'SP',
          amount: 11.99,
          type: 'out',
          date: new Date(now - 22 * 3600000).toISOString(),
          category: 'Entertainment',
          reference: 'Subscription',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-3',
          accountId: 'natwest-main-001',
          payeeName: 'SALARY - APEX TECH LTD',
          payeeInitials: 'AT',
          amount: 3450,
          type: 'in',
          date: new Date(now - 48 * 3600000).toISOString(),
          category: 'Income',
          reference: 'Direct Credit Monthly',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-4',
          accountId: 'natwest-main-001',
          payeeName: 'WAITROSE & PARTNERS',
          payeeInitials: 'WA',
          amount: 68.4,
          type: 'out',
          date: new Date(now - 72 * 3600000).toISOString(),
          category: 'Groceries',
          reference: 'Apple Pay',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-5',
          accountId: 'natwest-main-001',
          payeeName: 'AMAZON UK',
          payeeInitials: 'AM',
          amount: 34.99,
          type: 'out',
          date: new Date(now - 96 * 3600000).toISOString(),
          category: 'Shopping',
          reference: 'Online Purchase',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-6',
          accountId: 'natwest-main-001',
          payeeName: 'DELIVEROO LONDON',
          payeeInitials: 'DE',
          amount: 28.5,
          type: 'out',
          date: new Date(now - 110 * 3600000).toISOString(),
          category: 'Eating Out',
          reference: 'Card Payment',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-7',
          accountId: 'natwest-main-001',
          payeeName: 'OCTOPUS ENERGY',
          payeeInitials: 'OE',
          amount: 94,
          type: 'out',
          date: new Date(now - 144 * 3600000).toISOString(),
          category: 'Bills',
          reference: 'Direct Debit Electricity',
          currency: 'GBP',
          currencySymbol: '£',
        },
        {
          id: 'tx-8',
          accountId: 'natwest-main-001',
          payeeName: 'TRANSFER FROM SARAH',
          payeeInitials: 'SJ',
          amount: 120,
          type: 'in',
          date: new Date(now - 168 * 3600000).toISOString(),
          category: 'Income',
          reference: 'Weekend dinner split',
          currency: 'GBP',
          currencySymbol: '£',
        },
      ],
      autoGeneratedDays: {},
    };
    ensureDailyTransactions(db, 55);
    return db;
  }

  function loadStaticDb() {
    var db = null;
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.accounts) && Array.isArray(parsed.transactions)) {
          db = parsed;
        }
      }
    } catch (e) {}
    if (!db) {
      db = memDb || createInitialDb();
    }
    if (ensureDailyTransactions(db, 55)) {
      saveStaticDb(db);
    } else {
      saveStaticDb(db);
    }
    memDb = db;
    return db;
  }

  function saveStaticDb(db) {
    memDb = db;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    } catch (e) {}
  }

  function jsonResponse(data, status) {
    return new Response(JSON.stringify(data), {
      status: status || 200,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  function handleStaticApi(pathname, search, method, bodyText) {
    var db = loadStaticDb();
    var body = {};
    if (bodyText) {
      try {
        body = JSON.parse(bodyText);
      } catch (e) {}
    }

    if (pathname === '/api/admin/accounts' && method === 'GET') {
      return jsonResponse(db.accounts, 200);
    }

    if (pathname === '/api/admin/accounts' && method === 'POST') {
      var accountHolderName = body.name || body.nickname || 'NEW ACCOUNT';
      var initials = accountHolderName
        .split(' ')
        .filter(Boolean)
        .map(function (s) { return s[0]; })
        .join('')
        .slice(0, 2)
        .toUpperCase();
      var newAccount = {
        id: 'acc-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        name: accountHolderName,
        accountName: accountHolderName.toUpperCase() + ' / CUR',
        initials: initials || 'NA',
        accountNumber: Math.floor(10000000 + Math.random() * 90000000).toString(),
        sortCode: '60-12-34',
        balance: 0,
        overdraftLimit: 1000,
        savingsAccountNumber: Math.floor(10000000 + Math.random() * 90000000).toString(),
        savingsSortCode: '60-12-35',
        savingsBalance: 0,
        linkedAccountNumber: Math.floor(10000000 + Math.random() * 90000000).toString(),
        linkedSortCode: '04-00-04',
        linkedBalance: 0,
        customerNumber: Math.floor(10000000 + Math.random() * 90000000).toString(),
        address: '123 High Street\nLondon\nEC1A 1BB',
        phone: '+44 7700 900000',
        email: accountHolderName.toLowerCase().replace(/\s+/g, '.') + '@email.com',
        pin: body.pin || '2026',
        slug: (body.nickname || accountHolderName).toLowerCase().replace(/[^a-z0-9]/g, '-'),
      };
      db.accounts.push(newAccount);
      ensureDailyTransactions(db, 55);
      saveStaticDb(db);
      return jsonResponse(newAccount, 201);
    }

    if (pathname.indexOf('/api/admin/accounts/') === 0) {
      var accId = decodeURIComponent(pathname.slice('/api/admin/accounts/'.length));
      if (method === 'PATCH') {
        var idx = db.accounts.findIndex(function (a) { return a.id === accId; });
        if (idx === -1) return jsonResponse({ error: 'Account not found' }, 404);
        var updates = Object.assign({}, body);
        if (typeof updates.slug === 'string') {
          updates.slug = updates.slug
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9-]/g, '-')
            .replace(/^-+|-+$/g, '');
        }
        db.accounts[idx] = Object.assign({}, db.accounts[idx], updates);
        saveStaticDb(db);
        return jsonResponse(db.accounts[idx], 200);
      }
      if (method === 'DELETE') {
        db.accounts = db.accounts.filter(function (a) { return a.id !== accId; });
        db.transactions = db.transactions.filter(function (t) { return t.accountId !== accId; });
        if (db.autoGeneratedDays) delete db.autoGeneratedDays[accId];
        saveStaticDb(db);
        return jsonResponse({ success: true }, 200);
      }
    }

    if (pathname.indexOf('/api/accounts/') === 0 && method === 'GET') {
      var id = decodeURIComponent(pathname.slice('/api/accounts/'.length));
      var found = db.accounts.find(function (a) { return a.id === id; });
      if (!found) return jsonResponse({ error: 'Account not found' }, 404);
      return jsonResponse(found, 200);
    }

    if (pathname === '/api/account-by-number' && method === 'GET') {
      var params = new URLSearchParams(search || '');
      var raw = String(params.get('accountNumber') || '').trim().replace(/^\/+|\/+$/g, '');
      var norm = raw.toLowerCase();
      var acc = db.accounts.find(function (a) {
        return a.accountNumber === raw || a.id === raw || (a.slug && a.slug.toLowerCase() === norm);
      });
      if (!acc) {
        if (raw === '89026813' || norm === 'default') {
          return jsonResponse(db.accounts[0] || { accountNumber: raw }, 200);
        }
        return jsonResponse({ error: 'Account not found' }, 404);
      }
      return jsonResponse(acc, 200);
    }

    if (pathname.indexOf('/api/transactions/') === 0 && method === 'GET') {
      var txAccId = decodeURIComponent(pathname.slice('/api/transactions/'.length));
      var txs = db.transactions
        .filter(function (t) { return t.accountId === txAccId; })
        .sort(function (a, b) { return new Date(b.date).getTime() - new Date(a.date).getTime(); });
      return jsonResponse(txs, 200);
    }

    if (pathname === '/api/transactions' && method === 'POST') {
      var pName = body.payeeName || 'Transaction';
      var newTx = {
        id: body.id || 'tx-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        accountId: body.accountId,
        payeeName: pName,
        payeeInitials:
          body.payeeInitials ||
          pName.split(' ').map(function (w) { return w[0] || ''; }).join('').slice(0, 2).toUpperCase() ||
          'TX',
        amount: parseFloat(body.amount) || 0,
        date: body.date ? new Date(body.date).toISOString() : new Date().toISOString(),
        accountNumber: body.accountNumber || null,
        sortCode: body.sortCode || null,
        reference: body.reference || 'CARD PAYMENT',
        type: body.type === 'in' ? 'in' : 'out',
        category: body.category || 'General',
        currency: body.currency || 'GBP',
        currencySymbol: body.currencySymbol || '£',
        isInternational: !!body.isInternational,
        iban: body.iban || null,
        swiftBic: body.swiftBic || null,
        isPending: !!body.isPending,
      };
      db.transactions.unshift(newTx);
      var aIdx = db.accounts.findIndex(function (a) { return a.id === body.accountId; });
      if (aIdx !== -1) {
        if (newTx.type === 'in') db.accounts[aIdx].balance += newTx.amount;
        else db.accounts[aIdx].balance -= newTx.amount;
      }
      saveStaticDb(db);
      return jsonResponse(newTx, 201);
    }

    if (pathname.indexOf('/api/transactions/') === 0 && method === 'DELETE') {
      var delId = decodeURIComponent(pathname.slice('/api/transactions/'.length));
      db.transactions = db.transactions.filter(function (t) { return t.id !== delId; });
      saveStaticDb(db);
      return jsonResponse({ success: true }, 200);
    }

    if (pathname === '/api/transfer' && method === 'POST') {
      var numAmount = parseFloat(body.amount) || 0;
      if (numAmount <= 0) return jsonResponse({ error: 'Invalid amount' }, 400);
      var fromAcc = db.accounts.find(function (a) { return a.accountNumber === body.fromAccountNumber; });
      var toAcc = db.accounts.find(function (a) { return a.accountNumber === body.toAccountNumber; });
      var nowIso = new Date().toISOString();
      if (fromAcc) {
        fromAcc.balance -= numAmount;
        db.transactions.unshift({
          id: 'tx-out-' + Date.now(),
          accountId: fromAcc.id,
          payeeName: (toAcc && toAcc.name) || body.receiverName || ('Transfer to ' + body.toAccountNumber),
          payeeInitials: ((toAcc && toAcc.name) || body.receiverName || 'TR').slice(0, 2).toUpperCase(),
          amount: numAmount,
          date: nowIso,
          accountNumber: body.toAccountNumber,
          sortCode: body.toSortCode,
          reference: body.reference || 'TRANSFER',
          type: 'out',
          category: 'Transfer',
          currency: 'GBP',
          currencySymbol: '£',
        });
      }
      if (toAcc) {
        toAcc.balance += numAmount;
        db.transactions.unshift({
          id: 'tx-in-' + Date.now(),
          accountId: toAcc.id,
          payeeName: body.senderName || (fromAcc && fromAcc.name) || ('Transfer from ' + body.fromAccountNumber),
          payeeInitials: (body.senderName || (fromAcc && fromAcc.name) || 'TR').slice(0, 2).toUpperCase(),
          amount: numAmount,
          date: nowIso,
          accountNumber: body.fromAccountNumber,
          sortCode: body.fromSortCode,
          reference: body.reference || 'TRANSFER',
          type: 'in',
          category: 'Income',
          currency: 'GBP',
          currencySymbol: '£',
        });
      }
      saveStaticDb(db);
      return jsonResponse({ success: true, senderBalance: fromAcc ? fromAcc.balance : undefined }, 200);
    }

    if (pathname === '/api/push/subscribe' || pathname === '/api/push/send') {
      return jsonResponse({ success: true }, 200);
    }

    return jsonResponse({ error: 'Not found' }, 404);
  }

  var isStaticHost =
    typeof window !== 'undefined' &&
    (window.location.hostname.endsWith('.github.io') ||
      window.location.protocol === 'file:' ||
      window.__NW_STATIC_MODE__ === true);

  var origFetch = window.fetch.bind(window);
  window.fetch = async function (input, init) {
    var reqUrl = typeof input === 'string' ? input : input && input.url ? input.url : '';
    var parsed;
    try {
      parsed = new URL(reqUrl, window.location.origin);
    } catch (e) {
      return origFetch(input, init);
    }

    var isApi = parsed.origin === window.location.origin && parsed.pathname.indexOf('/api/') === 0;
    if (!isApi) return origFetch(input, init);

    if (parsed.pathname === '/api/logo' && isStaticHost) {
      var domain = parsed.searchParams.get('domain') || '';
      return origFetch('https://www.google.com/s2/favicons?domain=' + encodeURIComponent(domain) + '&sz=128');
    }

    var method = ((init && init.method) || (typeof input !== 'string' && input && input.method) || 'GET').toUpperCase();
    var bodyText = init && typeof init.body === 'string' ? init.body : '';

    if (isStaticHost) {
      return handleStaticApi(parsed.pathname, parsed.search, method, bodyText);
    }

    try {
      var res = await origFetch(input, init);
      var ct = (res.headers.get('content-type') || '').toLowerCase();
      // If hosted statically without a backend (405 or HTML 404 fallback), seamlessly switch to local browser engine
      if (res.status === 405 || (res.status === 404 && !ct.includes('application/json'))) {
        isStaticHost = true;
        return handleStaticApi(parsed.pathname, parsed.search, method, bodyText);
      }
      return res;
    } catch (err) {
      return handleStaticApi(parsed.pathname, parsed.search, method, bodyText);
    }
  };

  if (isStaticHost) {
    loadStaticDb();
    setInterval(loadStaticDb, 5 * 60 * 1000);
  }
})();
