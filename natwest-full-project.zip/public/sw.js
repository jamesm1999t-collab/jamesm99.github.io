const APP_CACHE = 'natwest-shell-v6';
const API_CACHE = 'natwest-api-v3';

const CRITICAL_URLS = [
  '/',
  '/manifest.json',
  '/nw-static-api.js',
  '/assets/index-Cx1TYxU6.js',
  '/assets/index-DBFHn-Id.css',
  '/natwest-app-icon.png',
];

const EXTRA_URLS = [
  '/assets/jspdf.es.min-D0FWm9mO.js',
  '/assets/html2canvas.esm-DXEQVQnt.js',
  '/assets/purify.es-Bzr520pe.js',
  '/assets/index.es-C87e_uEK.js',
  '/assets/aistudio/IMG_6057_ca6edeec.jpeg',
  '/natwest-app-icon.jpeg',
  '/fscs-logo.png',
  '/paralympicsgb-logo.png',
  '/teamgb-logo.png',
  '/assets/2AEC6FAF-1F02-4B5B-8F83-9D2376A8B4BA_1774089337193-I45wyf96.png',
  '/assets/902380DA-5E74-4242-9B98-5F9A4DBD7D7C_1774089042217-pItUq9pQ.png',
  '/assets/petsathome-D6leW-nD.png',
];

function isValidCacheableResponse(urlPath, res) {
  if (!res || !res.ok || res.redirected || res.type !== 'basic') return false;
  var ct = (res.headers.get('content-type') || '').toLowerCase();
  if ((urlPath.endsWith('.js') || urlPath.endsWith('.mjs')) && ct.includes('text/html')) return false;
  if (urlPath.endsWith('.css') && ct.includes('text/html')) return false;
  if (urlPath.endsWith('.json') && ct.includes('text/html')) return false;
  return true;
}

function precacheList(cache, urls) {
  return Promise.allSettled(
    urls.map(function(url) {
      return fetch(url, { credentials: 'same-origin' })
        .then(function(res) {
          if (isValidCacheableResponse(url, res)) {
            return cache.put(url, res);
          }
        })
        .catch(function() {});
    })
  );
}

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(APP_CACHE).then(function(cache) {
      precacheList(cache, EXTRA_URLS);
      return precacheList(cache, CRITICAL_URLS);
    }).then(function() {
      return self.skipWaiting();
    })
  );
});

self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches
      .keys()
      .then(function(keys) {
        return Promise.all(
          keys
            .filter(function(key) {
              return key !== APP_CACHE && key !== API_CACHE;
            })
            .map(function(key) {
              return caches.delete(key);
            })
        );
      })
      .then(function() {
        return self.clients.claim();
      })
  );
});

function fetchWithTimeout(request, timeoutMs) {
  return new Promise(function(resolve, reject) {
    var done = false;
    var timer = setTimeout(function() {
      if (!done) {
        done = true;
        reject(new Error('timeout'));
      }
    }, timeoutMs);
    fetch(request)
      .then(function(res) {
        if (!done) {
          done = true;
          clearTimeout(timer);
          resolve(res);
        }
      })
      .catch(function(err) {
        if (!done) {
          done = true;
          clearTimeout(timer);
          reject(err);
        }
      });
  });
}

self.addEventListener('fetch', function(event) {
  var req = event.request;
  if (req.method !== 'GET') return;

  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  var p = url.pathname;
  if (
    p === '/sw.js' ||
    p.startsWith('/@') ||
    p.startsWith('/src/') ||
    p.startsWith('/node_modules/') ||
    p.startsWith('/__') ||
    p.startsWith('/api/admin/export-')
  ) {
    return;
  }

  // Navigation requests (/, /go/:slug, /:slug, etc.)
  if (req.mode === 'navigate') {
    event.respondWith(
      caches.match('/').then(function(cached) {
        var netPromise = (cached ? fetchWithTimeout(req, 4000) : fetch(req)).then(function(res) {
          if (isValidCacheableResponse('/', res)) {
            var copy = res.clone();
            caches.open(APP_CACHE).then(function(cache) {
              cache.put('/', copy);
            });
          }
          return res;
        });
        return netPromise.catch(function() {
          if (cached) return cached;
          return fetch(req);
        });
      })
    );
    return;
  }

  // Same-origin API GET requests -> Network-first with Cache Storage fallback
  if (p.startsWith('/api/')) {
    event.respondWith(
      caches.open(API_CACHE).then(function(cache) {
        return cache.match(req).then(function(cached) {
          var netPromise = (cached ? fetchWithTimeout(req, 4000) : fetch(req)).then(function(res) {
            if (res && res.ok) {
              cache.put(req, res.clone());
            }
            return res;
          });
          return netPromise.catch(function() {
            return (
              cached ||
              new Response('null', {
                status: 200,
                headers: { 'Content-Type': 'application/json' },
              })
            );
          });
        });
      })
    );
    return;
  }

  // Static assets -> Only apply timeout when a cached copy exists; never return synthetic 504 on slow first load
  event.respondWith(
    caches.match(req).then(function(cached) {
      var netPromise = (cached ? fetchWithTimeout(req, 4500) : fetch(req)).then(function(res) {
        if (isValidCacheableResponse(p, res)) {
          var copy = res.clone();
          caches.open(APP_CACHE).then(function(cache) {
            cache.put(req, copy);
          });
        }
        return res;
      });
      return netPromise.catch(function() {
        if (cached) return cached;
        return fetch(req);
      });
    })
  );
});

self.addEventListener('push', function(event) {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'NatWest';
  const options = {
    body: data.body || '',
    icon: '/natwest-app-icon.png',
    badge: '/natwest-app-icon.png',
    vibrate: [200, 100, 200],
    tag: 'natwest-payment-' + Date.now(),
    renotify: true,
    silent: false,
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clientList) {
      for (var i = 0; i < clientList.length; i++) {
        var client = clientList[i];
        if ('focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(self.registration.scope);
    })
  );
});
