# NatWest Mobile Banking App

A faithful reproduction of the NatWest mobile banking application with complete backend support, real-time persistence, and an interactive Admin / Customization Panel.

## How to Make Updates

You have two convenient ways to make updates to accounts, balances, and transactions:

### 1. In-App Updates Panel
- **Quick-Access Button**: Click the **"Updates / Admin"** floating pill in the bottom-right corner.
- **Keyboard Shortcut**: Press `Alt + A` (or `Ctrl + Shift + A`) anytime to jump directly to the Admin Panel.
- **Native Gesture**: Triple-tap the NatWest logo on your Current Account card (or tap "Savings" 3 times on the **Apply** tab).

#### What you can customize in the Admin Panel:
- **Account Details**: Edit account holder name, account nickname, initials, customer number, account number, and sort code.
- **Balances**: Live number inputs for Current Account, Savings Account, Linked Monzo/Other Account, and Overdraft Limit.
- **Quick Increments**: Instant `+£100`, `+£500`, `+£1,000`, `+£5,000` and `-£100`, `-£500`, `-£1,000`, `-£5,000` adjustments.
- **Transactions Manager**:
  - Delete any existing transaction.
  - Add preset transactions from 65+ major UK & global merchants (Tesco, Waitrose, Sainsbury's, Amazon, Spotify, Netflix, Uber, etc.).
  - Add custom transactions (payee, amount, debit/credit type, category, reference).
- **Multi-Account Switching**: Create multiple accounts, switch between them, and perform instant inter-account transfers.

### 2. File & API Updates
- **Database file**: `data/db.json` stores all accounts and transaction history persistently.
- **Backend API**: `server.ts` handles:
  - `GET /api/admin/accounts` — list all accounts
  - `POST /api/admin/accounts` — create new account
  - `PATCH /api/admin/accounts/:id` — update account details
  - `DELETE /api/admin/accounts/:id` — delete account
  - `GET /api/transactions/:accountId` — fetch transactions
  - `POST /api/transactions` — add transaction
  - `DELETE /api/transactions/:id` — delete transaction
  - `POST /api/transfer` — inter-account transfer
  - `GET /api/logo?domain=...` — merchant logo proxy

### Default Credentials
- **Default PIN**: `2026`
- **Biometric Passkey**: Face ID / Fingerprint simulation enabled
